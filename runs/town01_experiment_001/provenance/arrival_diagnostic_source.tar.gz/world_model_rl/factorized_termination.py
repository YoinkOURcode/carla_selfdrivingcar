"""Training-only learned arrival and failure readouts for a frozen fresh RSSM."""

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from .config import Config
from .data import Dataset, write_json
from .deadline import TrainingClock
from .model import arrival_features
from .refit_termination import internal_partition
from .schema import EVENTS
from .training import termination_metrics


ARRIVAL_L2 = (1e-7, 1e-5, 0.001, 0.1)


def fit_natural_logistic(features, labels, l2, clock=None, progress=None, iterations=100):
    """Deterministic damped Newton fit at natural class frequency, in float64.

    A line search is read-only until an improving step is accepted. Deadline
    checks precede every committed update; no class balancing/threshold tuning.
    Returned coefficients include the bias as the final element.
    """
    x = torch.cat([features.double(), torch.ones(len(features), 1, dtype=torch.float64)], -1)
    y = torch.as_tensor(labels, dtype=torch.float64)
    weights = torch.zeros(x.shape[-1], dtype=torch.float64)
    penalty = torch.eye(x.shape[-1], dtype=torch.float64) * l2
    def objective(value):
        return F.binary_cross_entropy_with_logits(x @ value, y, reduction='sum') + .5 * l2 * value.square().sum()
    completed = 0
    for step in range(iterations):
        if clock is not None and clock.expired:
            break
        logits = x @ weights
        probabilities = logits.sigmoid()
        gradient = x.T @ (probabilities - y) + l2 * weights
        hessian = x.T @ ((probabilities * (1 - probabilities))[:, None] * x) + penalty
        direction = torch.linalg.solve(hessian, gradient)
        old = objective(weights)
        rate = 1.0
        for _ in range(50):
            proposal = weights - rate * direction
            if objective(proposal) <= old:
                break
            rate *= .5
        else:
            break
        if clock is not None and clock.expired:
            break
        weights = proposal
        completed += 1
        if progress is not None:
            progress(weights, completed)
        if float((rate * direction).abs().max()) < 1e-8:
            break
    return weights, {'updates': completed, 'natural_nll_sum': float(objective(weights)), 'l2': l2}


def logistic_probabilities(features, weights):
    return (features.double() @ weights[:-1] + weights[-1]).sigmoid()


def diagnose_arrivals(experiment):
    """Commit the design and select regularization using training episodes only."""
    root = Path(experiment)
    work = root / 'factorized_termination';work.mkdir(exist_ok=True)
    if (work / 'arrival_internal.json').exists():
        raise FileExistsError('Arrival diagnostic already complete; retain its committed result')
    cfg = Config.load(root / 'config.json')
    clock = TrainingClock(root / 'training_clock.json');clock.start()
    try:
        if clock.expired:
            raise RuntimeError('The shared training deadline has expired')
        torch.set_num_threads(4)
        train = Dataset(root / 'data', cfg).load('train')
        held, held_ids = internal_partition(train, cfg.training.seed + 5101)
        plan = {'method': 'learned-arrival-failure-factorization-v1', 'arrival_l2': ARRIVAL_L2,
            'created_utc': datetime.now(timezone.utc).isoformat(), 'device': 'cpu', 'threads': 4,
            'source_sha256': hashlib.sha256((root / 'world_model.pt').read_bytes()).hexdigest(),
            'source_config_sha256': hashlib.sha256((root / 'config.json').read_bytes()).hexdigest(),
            'diagnostic_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'arrival_fit': 'natural-frequency float64 damped Newton; 100 accepted steps maximum',
            'arrival_selection': 'internal training-episode natural log loss; stronger L2 breaks exact ties',
            'failure_head': {'hidden': 32, 'weight_decay': .001, 'latent_noise': 1.0,
                'updates': [500, 1000, 2000, 4000], 'batch_size': 1024,
                'selection': 'internal natural log loss; retain selected fit rather than refitting',
                'calibration': 'two scalars on natural-frequency internal training holdout'},
            'held_out_training_episode_ids': [train[i].metadata['episode_id'] for i in held_ids],
            'training_episode_ids': [ep.metadata['episode_id'] for ep in train],
            'external_validation_used_for_fit_selection_or_calibration': False,
            'deadline_unix': clock.value['deadline_unix']}
        write_json(work / 'plan.json', plan)
        continuous = torch.as_tensor(np.concatenate([ep.arrays['continuous'][:-1] for ep in train]))
        applied = torch.as_tensor(np.concatenate([ep.arrays['applied_actions'] for ep in train]))
        labels = np.concatenate([ep.arrays['events'][:, EVENTS.index('success')] > 0 for ep in train])
        features = arrival_features(continuous, applied)
        records, best = [], None
        for l2 in ARRIVAL_L2:
            weights, stats = fit_natural_logistic(features[~held], labels[~held], l2, clock)
            if clock.expired:
                raise RuntimeError('Shared deadline reached during arrival fitting')
            probabilities = logistic_probabilities(features[held], weights)
            nll = float(F.binary_cross_entropy(probabilities, torch.as_tensor(labels[held], dtype=torch.float64)))
            record = {'l2': l2, 'natural_holdout_nll': nll,
                'metrics': termination_metrics(probabilities.numpy(), labels[held]), 'fit': stats}
            records.append(record)
            if best is None or (nll, -l2) < (best['natural_holdout_nll'], -best['l2']):
                best = record
            print(json.dumps(record), flush=True)
            write_json(work / 'arrival_internal.json', {'records': records, 'selected': best})
        weights, stats = fit_natural_logistic(features, labels, best['l2'], clock)
        if clock.expired:
            raise RuntimeError('Shared deadline reached during final arrival refit')
        torch.save({'weights': weights, 'fit': stats, 'selected': best}, work / 'arrival_readout.pt')
        write_json(work / 'arrival_training.json', {'fit': stats,
            'metrics': termination_metrics(logistic_probabilities(features, weights).numpy(), labels)})
        return best
    finally:
        clock.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--experiment', required=True)
    parser.add_argument('--diagnose-arrivals', action='store_true')
    args = parser.parse_args()
    if not args.diagnose_arrivals:
        parser.error('Specify --diagnose-arrivals for the training-only arrival diagnostic')
    diagnose_arrivals(args.experiment)
