"""Natural-frequency event fits, safe deadlines and learned neural probabilities."""

import numpy as np
import torch
from torch.nn import functional as F

from world_model_rl.factorized_termination import fit_natural_logistic, logistic_probabilities


def test_natural_logistic_recovers_generated_probabilities_deterministically():
    rng = np.random.default_rng(18)
    x = torch.tensor(rng.normal(size=(5000, 2)), dtype=torch.float64)
    truth = torch.tensor([2., -1., -2.], dtype=torch.float64)
    probability = logistic_probabilities(x, truth)
    labels = rng.random(len(x)) < probability.numpy()
    weights, stats = fit_natural_logistic(x, labels, .1)
    repeated, _ = fit_natural_logistic(x, labels, .1)
    torch.testing.assert_close(weights, truth, atol=.15, rtol=0)
    torch.testing.assert_close(weights, repeated, atol=0, rtol=0)
    fitted = logistic_probabilities(x, weights)
    target = torch.tensor(labels, dtype=torch.float64)
    constant = torch.full_like(target, float(target.mean()))
    assert F.binary_cross_entropy(fitted, target) < F.binary_cross_entropy(constant, target)
    assert 0 < stats['updates'] <= 100


def test_newton_fit_does_not_commit_an_update_after_deadline():
    class Clock:
        checks = 0
        @property
        def expired(self):
            self.checks += 1
            return self.checks >= 3
    events = []
    _, stats = fit_natural_logistic(torch.arange(20, dtype=torch.float64)[:, None],
        np.arange(20) > 12, .01, Clock(), progress=lambda weights, count: events.append(count))
    assert stats['updates'] == 1 and events == [1]
