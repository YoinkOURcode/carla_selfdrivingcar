# Training with the collected recordings

The main `world_model_rl` package contains the collection and prototype changes,
including the geometry-v3 teacher, traffic-focused demonstrations, observed-state
policy input, telemetry, and optional object-order augmentation. Augmentation remains
disabled in the integrated profile, matching candidate 008's selected algorithm.

`configs/collected.json` uses candidate 008's training settings: a fresh SAC actor
with 50,000 expert warm-up updates, anchor weight 100, initial alpha 0.001, 50%
traffic-focused demonstration sampling, frozen world model, and no online collection
or model refresh during policy training. Its replay capacity is 1,000,000 steps so
all current training recordings fit. Rendering is enabled for future live collection.
`config.json` remains the general from-scratch pipeline configuration.

## Integrated data and model

The active dataset is `runs/world_model_rl/data`: **234 unique episodes, 220,420
transitions**, comprising 188 training, 23 validation, and 23 test episodes.
Only the 173,221 training transitions supply gradients. The dataset includes:

| Source | Added episodes | Duplicate episodes skipped |
| --- | ---: | ---: |
| `runs/town01_training_data_001` | 124 | 0 |
| `runs/experiment2/data` | 105 | 0 |
| `runs/experiment3/data` | 5 | 105 |
| `runs/experiment4/data` | 0 | 68 |
| `runs/manual/data` | 0 | 104 |

`runs/experiment1/data` has the older reward contract and is excluded. Evaluation
traces are never imported. Original source files remain untouched. Imported episodes
retain their source split and scenario seed; where numeric IDs collide, new IDs are
chosen with the same seeded split. Their `imported_from` metadata records the source
ID/path/split and a recording-content checksum. The first 124 episode IDs are
unchanged. Gaps in subsequent IDs are intentional; the initial next ID is 352.

`runs/world_model_rl/world_model.pt` is a byte-identical copy of the validated model
from prototype 001. It has not been jointly refitted on all 234 episodes. The policy
training command below uses all training recordings with this fixed encoder/model
and its saved normalizer. Its original fixed ten-episode validation suite remains
the gate in the default, single-contract mode; the other holdouts remain available.
This integration does not establish improved driving performance.

Audit/provenance: `world_model_rl/workspace.json`,
`runs/world_model_rl/data/imports.jsonl`, `runs/world_model_rl/data_audit.json`, and
`runs/world_model_rl/validation.json`. The runtime data/checkpoints live under
git-ignored `runs/`; keep that directory when moving or backing up the project.

## Restart policy training

Run from the repository root:

```bash
bash world_model_rl/train_collected.sh runs/town01_integrated_001 2000
```

This starts a **fresh SAC policy**, reuses the world model and all collected training
data, performs 50,000 expert warm-up updates followed by 2,000 SAC updates, and saves
`runs/town01_integrated_001/agent.pt`. It needs no running CARLA server. Logs go to
`runs/town01_integrated_001.log`; use a new output path for another fresh run.
Omitting arguments chooses a new output directory automatically. Nothing starts
until you invoke the command.

To resume that policy after interruption or add a further 2,000 SAC updates:

```bash
venv/bin/python -m world_model_rl train \
  --config runs/town01_integrated_001/config.json \
  --data runs/world_model_rl/data \
  --resume runs/town01_integrated_001/agent.pt \
  --output runs/town01_integrated_001 --policy-updates 2000
```

Resume requires the same dataset frontier and training settings. Do not resume a
prototype checkpoint against this enlarged dataset. After appending recordings or
changing the world model, start a new SAC output with `--model`; an old policy's
latent inputs and replay state should not be silently reused with changed dynamics.

## Add another town, weather, traffic level, or route distribution

Start a dedicated matching CARLA server for collection:

```bash
bash data/start_server.sh
```

In another terminal, append a fixed batch, for example Town02:

```bash
venv/bin/python -m world_model_rl collect \
  --config world_model_rl/configs/collected.json \
  --data runs/world_model_rl/data --allow-scenario-variation \
  --town Town02 \
  --weather ClearNoon HardRainNoon ClearNight HardRainNight FogNight \
  --episodes 100
```

Replace `Town02` with an installed CARLA map, or keep `Town01` and change `--weather`,
`--vehicles`, or `--pedestrians`. A single weather name is also supported. This uses
BasicAgent/noisy-BasicAgent collection; it does not change model weights. Existing
episodes and splits are retained. The map is loaded by the collection environment.
Only one driving client may own synchronous ticks on that server.

Then update the existing world model using the combined old and new training data:

```bash
venv/bin/python -m world_model_rl fit \
  --config world_model_rl/configs/collected.json \
  --data runs/world_model_rl/data --allow-scenario-variation \
  --warm-start runs/world_model_rl/world_model.pt \
  --checkpoint runs/world_model_rl/world_model_v2.pt --updates 10000
```

This fine-tunes the encoder/RSSM/prediction heads using training splits only, retains
the pretrained normalizer and optimizer, refits the termination readout, advances
model/version counters, and saves a new checkpoint without changing the source.
It writes `world_model_v2.coverage.json` and `world_model_v2.validation.json`.
For the next extension, pass `world_model_v2.pt` as `--warm-start` and choose a new
checkpoint name such as `world_model_v3.pt`.

In scenario-variation mode all validation episodes are used, including new towns.
Prediction and termination gates must pass in aggregate **and separately for each
town/weather/traffic/route configuration**. Training scenes without validation
coverage stop fitting/policy training before updates. A batch of 100 is a collection
budget, not a guarantee of enough independent endings or passing predictions.
Inspect the reports and add an independent collection batch if coverage is missing.

After model validation passes, train a fresh policy with the adapted model:

```bash
venv/bin/python -m world_model_rl train \
  --config world_model_rl/configs/collected.json \
  --data runs/world_model_rl/data --allow-scenario-variation \
  --model runs/world_model_rl/world_model_v2.pt \
  --output runs/multitown_001 --policy-updates 2000
```

The scenario flag permits town, weather schedule, traffic counts, child fraction,
route endpoints/length ranges, and connection settings to vary. It retains strict
checks for ego vehicle, action mapping/rates, timing/physics, termination settings,
observation provider/schema, reward definition/version, model architecture, and
split seed. Changing those contracts requires separate compatible data/model work.
This is CARLA scenario adaptation; another simulator needs an observation/action
adapter. Cross-town driving quality has not yet been measured.

## Import recordings collected into a separate dataset

```bash
venv/bin/python -m world_model_rl merge-data \
  --config world_model_rl/configs/collected.json \
  --data runs/world_model_rl/data --allow-scenario-variation \
  --source runs/another_collection/data
```

Multiple source paths can follow `--source`. This preflights compatibility, rejects
evaluation traces and cross-split reuse of a town/seed, skips duplicate recording
contents, preserves source splits/provenance, and never edits source files. Re-running
an import adds no duplicate episodes. After importing new environments, fine-tune
and validate the world model as above.
