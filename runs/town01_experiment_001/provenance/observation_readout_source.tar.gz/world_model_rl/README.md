# CARLA attention/RSSM + SAC

Point-to-point driving in Town01 using structured CARLA observations, masked attention,
a Gaussian RSSM with GRU memory, and SAC with real and validated imagined transitions.
[DESIGN.md](DESIGN.md) describes the model, observation contract and limitations.
[COMMANDS.md](COMMANDS.md) documents every CLI command, viewer option and launcher,
including defaults, examples, outputs, validation gates and resume requirements.

[PROTOTYPE.md](PROTOTYPE.md) records the Town01 changes, experiment results, exact
reproduction commands, warm-start/world-model operation and transfer instructions.
The goal is paused. No policy has passed the reserved final 50-episode evaluation.
Candidate 008 is the latest trained artifact; current object-permutation support is
newer than that checkpoint and has not been trained/evaluated with the option enabled.
Its completed development result is 4/10 arrivals, one collision, five timeouts and
eleven red-light violations; it does not meet the target.

For the integrated prototype code, **234 unique compatible collected episodes**,
restart/resume commands, and adding other towns/weather to the existing world model,
see [COLLECTED_TRAINING.md](COLLECTED_TRAINING.md). Start offline policy training with:

```bash
bash world_model_rl/train_collected.sh runs/town01_integrated_001 2000
```

This uses `configs/collected.json`, `runs/world_model_rl/data`, and the preserved
world model. It starts a new SAC policy with 50,000 expert warm-up updates and then
2,000 SAC updates. `fit --warm-start` separately supports world-model fine-tuning;
scenario transfer requires explicit `--allow-scenario-variation` and held-out checks.

## Train from scratch

Use the repository `venv/`. Start a dedicated CARLA server in another terminal:

```bash
bash data/start_server.sh
```

The server launcher requires `UE4_ROOT` to point to the built Unreal Engine.
Client and server must use the same CARLA build. Do not share a synchronous server
with another ticking client.

From the repository root, start the complete training pipeline:

```bash
bash world_model_rl/train_from_scratch.sh
```

Each invocation chooses a new `runs/from_scratch_<timestamp>_<suffix>` directory.
To specify the output, SAC update budget, and optionally a configuration:

```bash
bash world_model_rl/train_from_scratch.sh runs/experiment4 100000
bash world_model_rl/train_from_scratch.sh runs/experiment5 50000 my_config.json
```

The script rejects an existing output directory or log. It does not launch training
until you run it. It streams progress to your terminal and `OUTPUT_DIR.log`, preserving
the training command's failure exit status. Configuration paths and relative output
paths are resolved from the repository root.

At the default configuration, a fresh run:

1. Collects 20 new episodes with alternating BasicAgent/noisy-BasicAgent controllers,
   new episode seeds/routes, and the configured day/night/rain/fog conditions.
   Checks training and fixed validation-split event coverage before any gradient updates.
   Missing task endings or nonterminal support stops the run and saves a coverage report.
2. Fits normalization using only the new training split. Randomly initializes attention,
   RSSM, all prediction heads, and the model optimizer; performs 10,000 joint updates
   followed by 2,000 termination-readout updates on full real histories.
3. Saves `world_model.pt` and evaluates a held-out prediction/termination suite.
4. If validation passes, initializes fresh SAC actor/critics/optimizers and performs
   100,000 policy updates in 10,000-update blocks, using 75% real and 25% imagined replay.
5. Between policy blocks, collects two episodes using the current SAC actor, refreshes
   the world model, rebuilds latent replay, and validates before further SAC updates.

`run` requires a new or empty output directory and at least ten bootstrap episodes.
It never reuses data or weights from an existing experiment. The configuration is saved
in the output before collection. Existing experiments are retained as separate artifacts.
The launcher always starts a fresh run; it has no checkpoint input.

Collection and environment evaluation require CARLA; fitting and SAC optimizer blocks
use recorded replay without connecting to CARLA. `training.device=auto` selects CUDA
when available, otherwise CPU. Use `cuda` in a copied config to require the GPU.

## Watch driving episodes

While collection/training is running, open another terminal in the repository root:

```bash
venv/bin/python -m world_model_rl.viewer --config runs/experiment4/config.json
```

Open http://127.0.0.1:8080 in your browser. Use the config path for your current run.
The viewer attaches its own chase camera to the training vehicle and follows new
vehicles across bootstrap and SAC collection episodes. It also works with the offscreen
server. It never advances simulation ticks, changes world settings or controls the car.
It waits between driving sessions; fitting/SAC replay updates have no car to follow.
Extra camera rendering uses some GPU time. Ctrl+C stops the viewer and removes its camera.
No additional packages are required. Use `--port 8081` if the default browser port is busy.
This is a live view; existing NPZ recordings do not contain camera videos for past episodes.

The dashboard shows current speed in km/h and m/s, recognized object slots (class,
actor ID, ego-relative position and provider confidence), and the accumulated reward
for the current episode. It also compares actual speed against the observation's cautious
target speed, shows route completion and distance remaining along the route, and displays
the applied steering, throttle and brake values after action limits. The reward breakdown
lists each component for the last decision and its accumulated episode total, including
negative costs. Rewards and their component totals reset at each episode. With the default
provider, objects come from CARLA ground truth with geometric visibility filtering;
they are not camera-based detector predictions.

During SAC/DAgger driving, the attention panel shows the actual encoder weights over
ego state, route, weather, traffic controls, five waypoints and present object slots.
Choose an individual head or the mean of all heads. Empty slots are masked. These
weights describe the structured input attention, not a pixel heatmap or proof of why
the policy chose an action. Bootstrap/expert-only episodes do not run the encoder,
so their attention is unavailable.

Restart the viewer and the driving process after updating to this version. Telemetry
from a process started before the expanded panels was added lacks their fields; the
viewer explains when saving progress and restarting collection/training is required.
Restarting only the viewer or refreshing the browser cannot add those missing values.
Telemetry
is shared through an atomic local temporary JSON snapshot keyed by CARLA host/port;
both processes must run as the same user on the same machine and use the same CARLA
endpoint. No new CLI options or dependencies are needed. State updates happen once
per driving decision; the chase camera is a separate sensor and may show a different
simulation frame. State older than five wall-clock seconds is marked stale. Offline
fitting and replay have no live driving state to display.

## Validation and budgets

A failed validation gate stops SAC with exit code 2 and writes `validation.json`.
More independent ending/nonterminal data or changes to observable hazard coverage may
be necessary. Twenty ordinary collection episodes do not guarantee a passing gate.
Review event support, precision/recall, per-ending diagnostics, and prediction errors;
the program does not lower thresholds or substitute real-only policy training.
Optional policy experiments can set `training.behavior_cloning_updates` (default 0),
`behavior_cloning_weight` (default 0), and `policy_observation_skip` (default false).
With the `recorded` teacher, warm-up initializes the fresh actor from training-split
`autopilot` requests or separately recorded DAgger expert labels;
it never loads an old SAC policy. Warm-up counts are separate from SAC updates.
The demonstration penalty uses deterministic actor requests and Q normalization;
demonstration batches balance turns/braking with cruising. The observed-state skip
adds normalized structured observations alongside RSSM features. Real replay and live
driving use current observations; imagined skips use the model's predicted state,
masks, classes and light, with known controls/weather supplied causally. These are
explicit algorithm variants, not automatic recovery or an expert override at runtime.

`training.behavior_cloning_teacher` defaults to `recorded`, which uses actual expert
requests or the separate DAgger labels. The optional `geometry_v1` experiment instead
computes counterfactual pursuit/speed requests from current structured training states:
curvature-limited cornering, observed light stopping, and observed-object clearance.
It may use any training collector's states, including recovery states; validation/test
states remain forbidden. These are teacher-generated labels, not measured simulator
actions. Dynamics/critic replay still uses the measured executed controls and rewards.
The teacher is not called during policy evaluation. This variant is calibrated for the
Tesla Model3 configuration and must establish its driving quality in held-out rollouts.
`geometry_v2` keeps those longitudinal labels and calibrates pursuit steering using
the measured Tesla wheelbase (approximately 3.0 m), 70-degree front-wheel steering,
and CARLA's speed-dependent steering curve in km/h. Each teacher version stays explicit
in configuration/checkpoints so an earlier experiment's label rule is reproducible.
`geometry_v3` additionally holds at least 0.35 brake with zero throttle when the
teacher's desired speed is at most 0.3 m/s. This prevents the speed servo's cruise
feed-forward from teaching creep through a stopped lead vehicle or red light.
It does not guarantee the learned actor stops: candidate 007 still recorded ten
red-light violations over its ten development episodes.

`behavior_cloning_traffic_fraction` defaults to 0. At 0.5, half each demonstration
batch focuses on near red/yellow braking states, split three quarters moving and one
quarter waiting; the remainder retains manoeuvre/uniform sampling. Candidate 008
uses this option. `behavior_cloning_permute_objects` defaults false and requires
`policy_observation_skip`. When enabled, demonstration geometry/masks/classes are
permuted together within vehicle/pedestrian slot groups, preserving teacher labels.
It affects actor demonstration fitting only; no trained checkpoint uses it yet.

For additional recovery-state demonstrations, `collect --policy-checkpoint agent.pt
--expert-probability 0.5` executes a seeded mixture of the deterministic policy and
BasicAgent while recording separate `expert_actions` at every visited state. These
episodes are labelled `dagger`. Dynamics/Q replay always use the executed requests and
applied actions; demonstration fitting uses the separate expert labels. Only training
splits supply demonstrations. Use an isolated dataset copy when preserving a resumable
agent's recording frontier; never collect development or final evaluation seeds for fitting.

For the structured ground-truth provider, `environment.no_rendering_mode: true`
disables viewport drawing to improve simulation throughput. Physics, timing and reward
settings stay fixed. Existing structured recordings/models remain compatible across
this rendering switch. Camera-based providers require rendering, and the live camera
viewer needs it enabled. The previous world setting is restored when the environment closes.

`evaluate --plan PATH` accepts a fixed JSON scenario plan with format 1, town, and a
`scenarios` list containing unique `episode_id`, `seed`, and scheduled `weather` values.
The plan overrides `--episodes` and scenario seeds from `--seed-offset`. Evaluation
never saves its trajectories into the training dataset. Results are saved after each
episode, with completion status and per-weather metrics. Existing result files cannot
be overwritten. Prototype acceptance requires all 50 planned episodes, ten in each of
five configured weathers, at least 80% successes, and at most 10% collision episodes.
A partial run or a smaller development suite cannot establish acceptance.
Reports also include red-light violation totals, violating-episode counts and rates
overall and per weather. A route arrival can still contain traffic violations.
`evaluate --record-traces` additionally saves diagnostic NPZ/JSON traces alongside
the result in a separate directory. These carry `split: evaluation` and explicit
never-train provenance; dataset save/load rejects them. They may be inspected for
failure analysis but must not be used for model or policy gradient updates.
`termination.by_episode` breaks event metrics down by episode. `termination.false_positive_groups`
describes the first up to 20 contiguous false-alarm stretches in time order, including
weather, transition range, duration, probabilities, observed speed/route distance and
visible-object counts. The total group count and all false positives remain in the metrics.
These are diagnostic contexts, not demonstrated causes or permission to fit on validation.

Before fitting, `validate --for-training` checks recorded task-ending/nonterminal
support in training and the first up to `training.validation_episodes` validation
episodes. `fit` performs the same check before allocating a model and writes
`CHECKPOINT.coverage.json`. Time-limit and stuck truncations count as nonterminal
transitions; only true task terminations (such as success or collision) are positives.
The check preserves all split assignments and does not select episodes by outcome.
Adequate label support alone does not establish prediction quality; the later model
validation gate remains required.

For an experiment blocked before SAC because held-out task endings are absent:

```bash
venv/bin/python -m world_model_rl validate --config runs/experiment4/config.json --data runs/experiment4/data --for-training
bash world_model_rl/recover_from_scratch.sh runs/experiment4 20 100000
```

With a dedicated CARLA server running, the recovery script appends exactly 20 new
episodes to that dataset, checks coverage, fits randomly initialized world-model
weights in a new `runs/experiment4/recovery_<timestamp>_<suffix>` directory, and starts
a fresh SAC policy only if validation passes. Existing checkpoints and recorded
episodes remain intact. No old weights are loaded. Progress is saved to the new
output's sibling `.log`. It stops before fitting if the fixed additional batch still
lacks coverage; it never loops until favorable validation outcomes appear. A run that
already has `agent.pt` is refused to protect its dataset/checkpoint frontier.
If the validation suite has already reached its configured episode cap, appending more
episodes does not replace its existing members; plan a broader suite explicitly before
fitting a new experiment rather than selecting favorable endings or using the test split.

The recovery output uses the original run's external dataset. To recover an interrupted
SAC session there, use `train --data runs/experiment4/data --resume OUTPUT_DIR/agent.pt
--output OUTPUT_DIR --config OUTPUT_DIR/config.json` with your update budget.

`--policy-updates` counts SAC optimizer updates. `--episodes` instead counts real SAC
collection episodes, in addition to bootstrap episodes; these flags are mutually exclusive.
Imagination spans one decision (0.1 s) by default and is regenerated every 100 SAC updates.
The normalizer stays fixed during a run; replay is rebuilt when the model changes.

## Individual stages

Use a new directory and collect fresh data:

```bash
venv/bin/python -m world_model_rl collect --data runs/manual/data --episodes 20
venv/bin/python -m world_model_rl validate --data runs/manual/data
venv/bin/python -m world_model_rl fit --data runs/manual/data --checkpoint runs/manual/world_model.pt --updates 10000
venv/bin/python -m world_model_rl train --data runs/manual/data --model runs/manual/world_model.pt --output runs/manual --policy-updates 100000
```

`fit` always creates a new model, normalizer and optimizer, and refuses to overwrite its
checkpoint. `train --model` accepts a fitted world-model checkpoint and starts a new SAC
policy. `fit-termination` remains available to refit only a current world model's ending
readout; it does not import an actor or critics.

Explicit recovery of the *same interrupted run* is separate from starting a new run:

```bash
venv/bin/python -m world_model_rl run --config runs/manual/config.json --output runs/manual --resume --policy-updates 10000
```

This requires `agent.pt`, restores all networks/optimizers/RNG state and phase counters,
and adds 10,000 updates. Dataset/checkpoint frontier mismatches stop for inspection.
An unfinished simulator episode restarts from its seed. The from-scratch launcher
never requests resume. Checkpoints are saved every 1,000 SAC updates and at phase boundaries.

## Evaluation and artifacts

```bash
venv/bin/python -m world_model_rl evaluate-model --config runs/manual/config.json --data runs/manual/data --checkpoint runs/manual/agent.pt --split test --output runs/manual/test_model.json
venv/bin/python -m world_model_rl evaluate --config runs/manual/config.json --checkpoint runs/manual/agent.pt --episodes 10 --output runs/manual/evaluation.json
```

`data/` stores numeric NPZ episodes, provenance and fixed episode splits. `world_model.pt`
stores the initial fitted model, optimizer and normalizer; `agent.pt` also contains SAC
state and the latest refreshed model. `training.jsonl`, `world_model_training.jsonl`,
and `termination_training.jsonl` record update counters, fitting metrics and timings.
The launcher's sibling `.log` contains collection summaries and printed stage progress.
No automatic completion notification is configured.

The observation provider defaults to structured CARLA ground truth. A perception
provider can be selected through `environment.observation_provider`; a changed observation
contract requires a new compatible dataset and model. See DESIGN.md.

## Offline verification

```bash
venv/bin/python -m pytest world_model_rl/tests -q
```

Tests use generated arrays, small networks and fake environments. They do not start
CARLA or run full training. See [VALIDATION.md](VALIDATION.md) for evidence and limitations.
