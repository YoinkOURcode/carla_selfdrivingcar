# Implementation verification

## Fresh-run termination failure and controlled readout recovery

The fresh 20,000-update model passed its one-step prediction/reward tolerances but
failed the unchanged precision gate: TP=3, FP=69, FN=3 (precision 0.0417, recall
0.5). Only one of three collision endings was detected. Training precision was
0.902, exposing a large generalization gap. SAC did not start from this model.

`refit_termination.py` compares smaller, regularized readouts on an episode holdout
inside the existing training split. Capacity, noise, regularization and update
budgets are committed before internal results. The chosen setting is refitted on
all training episodes and externally validated once. Body/reward/normalizer,
persisted splits, final seeds, thresholds and the five-hour deadline stay fixed.
This recovery has no demonstrated driving result yet.

## Crossing-total reporting correction during fitting

Thirty-one evaluation/selection/numerical integration tests pass in 2.20 seconds.
The added case preserves three red crossings within one decision as three
violations and one violating episode, without changing arrival/collision acceptance.
New live summaries retain raw event multiplicities as well as decision counts;
legacy reports are preserved. No development/final outcome was used for this fix.
AST fingerprints verify that `fit`, `fit_termination` and `train` are unchanged.
The running fit keeps its loaded source; separate evaluation-source provenance is
saved under the experiment so later policy/evaluation imports remain traceable.

## Full host access and fresh objective profile — 17 October 2026

CARLA/GPU access is restored. Read-only preflight verified matching
`e6c5fb9ce-dirty` client/server versions, Town01, asynchronous idle ticking, no ego
vehicle and no competing TCP driving client. GPU is an RTX 4070 Ti. The old
permission failures below are historical. Full suite after objective/teacher/
determinism and post-deadline selection integration: **116 passed in 6.94 seconds**.
The complete output is saved in the experiment's `logs/offline_tests_before_training.log`.
A generated-fixture
CUDA forward/backward smoke test passed strict deterministic checks.

New tests verify immutable raw rewards versus consistent sequence/replay/validation
learning targets, rejection of incompatible reward-head checkpoints, v4 stop/release
labels, applied-control imitation gradients and deterministic draws. Earlier seven
deadline tests still pass. No actual driving improvement is claimed from these tests.
The fixed 20-episode collection batch is predeclared in the experiment manifest;
model fitting and policy training have not started at this documentation update.
Selection tests also cover fixed-time SAC eligibility, exclusion of partial/final
selection evidence, exact checkpoint provenance, refusing to create a clock from
the evaluation workflow, and saving unchanged frozen model tensors at the deadline.

## Timed training implementation — 17 October 2026

The authoritative `deadline.py`, `training.py`, `runner.py` and CLI now support a
persisted shared five-hour offline budget and five-minute candidate archives.
Expiry stops further optimizer updates while preserving completed model/policy
state, actual counters and RNG. Partial actor warm-up can be resumed without
repeating completed updates. Timed policy updates explicitly reject live
collection/refresh settings. Existing gates, split assignments, action mapping
and neural evaluation are unchanged. See the timed workflow in COMMANDS.md.

Full offline result after these changes: **105 passed, one failed in 4.71 s**.
The same viewer socket test remains denied by the task environment. Seven new
numerical tests cover a shared/non-resettable deadline, concurrent-clock
rejection, immutable archive hashes, expiry during joint fitting, termination
fitting, actor warm-up, SAC and imagination, preserved optimizer/RNG state,
remaining-warm-up recovery, and rejection of timed live collection. These use
generated arrays and small networks, not the experiment's recordings.

No experiment training command or clock has been started. No `world_model.pt`
or `agent.pt` exists for this request. CARLA socket creation and GPU access
remain blocked; implementation tests do not establish driving acceptance.

## Active request preflight — 17 October 2026

The resumed Town01 request has not started training. Its current-state audit is
[`runs/town01_experiment_001/PREFLIGHT_20261017.md`](../runs/town01_experiment_001/PREFLIGHT_20261017.md),
with exact commands in the linked ledger and recording/source/plan hashes in its JSON evidence.
All 275 saved episodes (263,099 transitions; 221/27/27 train/validation/test) pass
the existing data checks. The fixed validation suite retains three collisions,
three arrivals and four timeouts. Final/development plans have no dataset or
mutual seed overlap. Neither required checkpoint is present; copied historical
metadata and reports do not prove fresh training for this request.

Current offline verification is **98 passed, one failed in 4.14 seconds**. The
viewer HTTP test fails because this task cannot create a local socket. The same
permission restriction blocks the required existing CARLA endpoint before a
connection can be attempted. CUDA is unavailable, and host driving processes
cannot be inspected from the sandbox PID namespace. No server/client was started
or restarted. The user authorized session access, but a fresh probe still failed
under the enforced task permissions. The user specified frequent checkpoints,
stopping training at five hours, then evaluating the best saved model. The clock
has not started. The older
paused-goal and 90-test statements below remain historical evidence.

## Current evidence — 17 October 2026

The Town01 goal is paused. Full changes, artifact paths, reproduction commands,
warm-start/world-model operation and transfer limits are in
[PROTOTYPE.md](PROTOTYPE.md). The sections below this current record retain the
historical verification of earlier implementation stages; their “not run” statements
refer to those stages, not the later Town01 experiments.

- Latest full offline suite: **90 passed in 4.88 seconds on the host**. This includes
  causal observation skips, expert/DAgger label separation, fixed evaluation plans,
  protected never-train traces, traffic-stratified demonstrations, red-light metrics
  and scene-preserving object permutation. The viewer test requires local socket access.
- Preserved 104 original episodes and splits; isolated extension added a fixed 20
  expert/policy-mixture episodes. Data audit verifies all 208 original files and their
  isolated copies unchanged, reserved seeds excluded, and all old splits preserved.
- Reusable frozen model report: ten held-out episodes, including three collisions,
  three successes and four timeouts; 11,880 transitions. One-step normalized RMSE
  0.582123, reward MAE 0.399445, speed MAE 0.889849 m/s, lane MAE 0.109471 m and
  heading MAE 0.022299 rad pass unchanged gates. Termination TP=3, FP=1, FN=3,
  recall 0.5 and precision 0.75 pass aggregate gates, **but all three collision
  endings are missed**. The aggregate gate does not establish collision safety.
- Candidate 007 completed development: **5/10 successes, one collision episode,
  four timeouts, ten red violations in seven episodes**. It was rejected.
- Candidate 008 completed 50,000 actor warm-up and 2,000 fresh SAC updates with
  traffic-focused demonstrations. Its model tensors match the frozen source exactly;
  `checkpoint_audit.json` records this. The previously started evaluation finished
  during documentation: **4/10 arrivals, one collision, five timeouts, eleven red
  violations in seven episodes**. It fails the target; traffic sampling did not fix
  the measured red-light problem. No training/evaluation process remains live.
- No final 50-episode evaluation has been performed. No candidate is accepted.
- Current object-permutation augmentation has passed offline semantic tests but has
  not been enabled in training or evaluated as a driving policy. Its motivation is
  the read-only 008 audit: equivalent slot reorderings changed braking decisions on
  36.8% of sampled held-out recording states. No gradients used those states.

Evidence: `runs/town01_collection_001/data_audit.json`,
`runs/town01_prototype_008/validation.json`, `checkpoint_audit.json`,
`action_generalization_audit.json`, and the per-experiment development reports.
These are research results, not a safety certification or transfer demonstration.

## Historical verification — 16 October and early 17 October 2026

## Fresh training workflow

Fresh `run` commands now reject nonempty output directories before collecting or fitting.
They collect a new dataset, compute its training-only normalizer, fit a randomly
initialized world model/optimizer, and initialize a fresh SAC actor/critics/optimizers
after validation. `fit` always starts from scratch. Old experiment directories are
retained as artifacts and are never selected by the from-scratch launcher.

The old conversion command, checkpoint import option for model fitting, automatic
checkpoint discovery, conversion module and reward-relabeling helper have been removed.
The CLI rejects the removed command/options. Initial policy training accepts a fitted
world-model checkpoint, not a SAC agent used as a source model. Explicit same-run
checkpoint resume remains available for interruption recovery.

`train_from_scratch.sh` checks arguments/output isolation, streams logs to the terminal
and a sibling `.log`, and preserves the training command's exit status through `tee`.
It does not start another CARLA server or train until the user runs it.

## Offline verification

```bash
venv/bin/python -m pytest world_model_rl/tests -q
bash -n world_model_rl/train_from_scratch.sh
bash world_model_rl/train_from_scratch.sh --help
venv/bin/python -m world_model_rl --help
```

**58 tests passed** in 3.30 seconds on CPU. Shell syntax, CLI help and package compilation also passed.

The tests use synthetic arrays, small networks, fake environments and a fake interpreter
for launcher checks. They never start CARLA or fit on the user's driving recordings.

Coverage includes:

- Existing-output rejection before collection/fitting, preserving artifact bytes.
- Rejection of removed CLI entry points and SAC agents as initial world models.
- Fresh fitting without checkpoint loading; new model/optimizer counters and training-only scaling.
- Launcher paths containing spaces, log streaming, refusal to overwrite logs, and exit codes 0/2/134.
- Action clipping/slew limits, coordinate signs, tracked slots, schema persistence and split isolation.
- Attention masking, recurrent histories, world-model gradients, encoding cache invalidation.
- Ending-tail sampling, training-prior termination correction, held-out event metrics and diagnostics.
- Termination-only fitting, source-checkpoint preservation and failed-gate reporting.
- SAC targets, truncation handling, short imagination and causal weather/control propagation.
- Policy update blocks, model refresh, same-run interruption recovery and evaluation seeds.
- Comfort reward bounds, traffic controls, sensor-frame timing, child caution and custom perception.

## Prior run and remaining live checks

The previously launched `experiment3` pipeline is no longer running. Its collection
process aborted after CARLA timeouts, and the pipeline recorded exit code 134.
Its log and recorded episodes remain under `runs/experiment3/`; its obsolete launcher
was removed. No replacement training process was launched during this change.

Existing experiment2 validation reports showed failed held-out termination recall.
Those reports describe that old model and do not validate a new randomly initialized
model. The unchanged gate can also reject a fresh run when event support, discrimination
or continuous prediction quality is inadequate. Twenty collection episodes are a starting
budget, not a guarantee that SAC can begin.

The new launcher has not been exercised against live CARLA. Start a dedicated matching
server and verify collection/reset, actor cleanup, sensor alignment and event coverage.
The renderer still needs graphics during collection. Full neural training and closed-loop
policy evaluation remain user-run work. Offline tests do not establish driving success,
safe behavior or sample-efficiency improvements.

## Live driving viewer

The browser viewer was started against the current experiment4 bootstrap collection.
Its local status endpoint reported a live vehicle and its frame endpoint returned a
960 by 540 PNG. Visual inspection confirmed a rear chase view of the training Tesla.
The viewer creates/removes its own RGB camera and does not tick, change settings,
or control the vehicle. Offline tests verify PNG RGB color order/chunk integrity and
attachment/cleanup across episode changes using a fake CARLA interface. No browser
automation surface was available to verify the page in a browser; the user can open
http://127.0.0.1:8080 locally.

## Experiment4 missing held-out endings

The saved experiment4 report contains 20 collected episodes. Training has 16 episodes:
six collision endings, five successful endings and five time limits. Validation episodes
8 and 14 both reached time limits: zero task endings and 3,600 nonterminal transitions.
The two test episodes are successful routes; they are not moved into validation or training.
The termination head's saved training report detects all 11 training endings without
false positives. Held-out precision/recall are undefined when no endings are present and
none are predicted. One-step continuous/reward checks pass; missing event support blocks SAC.

Initial fitting now checks coverage before choosing a training device or creating a model.
The check writes a `.coverage.json` report and cleanly exits with code 2 when support is
missing. `validate --for-training` exposes the same check without fitting. The gate still
rejects zero-ending validation, but no longer mislabels undefined recall/precision as
failed measured tolerances. Existing configured prediction and event thresholds are retained.

New tests cover early failure without device/model/gradient allocation, preservation of
recordings/splits, fixed validation-suite membership, missing training endings, clean CLI
failure and undefined metrics. Fake-interpreter tests exercise the recovery script's fixed
collection batch, preflight-before-fitting order, fresh checkpoint selection and propagated
failure status. The recovery script has not been run against CARLA or the user's data.
No new episodes, fitted models or policy updates were produced during this change.

## Recovery precision failure

Read-only CPU inference reproduced the recovery checkpoint's precision failure in
`runs/experiment4/recovery_20261017_001830_7066/`. There are four held-out episodes
(8, 14, 22, 30) with 6,233 transitions. The sole true task ending is a successful arrival
in episode 30; it is detected. All 28 false positives are episode 8 transitions 520–547,
a contiguous 2.8-second stretch in HardRainNight. Recorded forward speed is approximately
zero, route distance remaining is 257.707 m, and one object token is visible before each
action. Their ending probabilities range from 0.516 to 0.955. This locates a false-alarm
context; it does not establish which input or architectural choice caused the predictions.
Validation includes no collisions, so collision generalization remains unvalidated.
The saved head fit reports 26/26 training endings and no training false alarms; this
train/held-out gap is consistent with overfitting but does not identify a unique cause.

`false_positive_diagnosis.json` records the initial inference inspection, and
`validation_diagnostics.json` contains the extended model report. The source checkpoint,
original reports, data and split assignments were preserved. No gradient updates, new
collection or SAC training were run. Reports now include per-episode confusion counts and
bounded contiguous false-alarm contexts; the precision-failure message directs inspection
there rather than suggesting missed/hidden collision hazards for a recall-passing result.
All existing gate tolerances remain unchanged. No threshold is fitted to held-out outcomes.
