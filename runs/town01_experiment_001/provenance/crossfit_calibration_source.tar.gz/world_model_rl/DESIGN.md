# Implementation: design and operating contract

The optional `refit_termination` recovery module controls readout capacity without
changing RSSM checkpoint shapes. It standardizes action-conditioned prior features
using its training subset, fits 8/32/128-unit two-layer ELU heads with input noise
and L2 regularization, and selects a committed update count on an internal training
episode holdout. It folds normalization into the first linear layer and zero-pads
the smaller head into the original MLP exactly. It then refits all training data
before one external gate check. The frozen representation has seen the full
training split, so the internal holdout is a readout-selection aid, not an unbiased
world-model quality estimate. Existing external validation and final driving
evaluation remain required. This explicit recovery consumes the original shared
clock and cannot authorize updates after its deadline.

`calibrate_termination` adds five-fold readout bagging with the previously selected
training-only capacity and update budget. Each training prediction used to fit the
positive logit scale/intercept comes from a readout that excluded that episode.
Calibration minimizes unweighted BCE at natural event prevalence, without changing
the 0.5 probability threshold. The deployed ensemble averages logits and is folded
into block-diagonal hidden layers of the original MLP; this preserves exact neural
inference and checkpoint shapes. The frozen body has seen all training episodes,
which limits the interpretation of the internal cross-fit estimate. External
gating and final driving evaluation are still required.

Numeric defaults are research settings. Live Town01 training and development evaluation
have now been performed; the requested final 50-episode result has not been achieved
or measured. See [PROTOTYPE.md](PROTOTYPE.md) for changes, measured failures, exact
reproduction commands and transfer instructions. The latest trained candidate is 008;
object-order augmentation is implemented but has not been used to train a checkpoint.

## 1. What the system learns

The fresh `town01_experiment_001` profile adds explicit optional learning-cost
multipliers, a training-only `geometry_v4` teacher, applied-control imitation loss,
strict PyTorch determinism and a shared wall-clock deadline. Package defaults
remain unchanged. See COMMANDS.md and the experiment manifest for selected values.
Raw real rewards/components are preserved; the versioned learning target is
`raw_reward - (red_multiplier-1)*20*red_count - (collision_multiplier-1)*100*collision_count`
for this dataset. Sequence loss, real replay, held-out reward errors and the learned
imagination reward share that target. Model loading checks its separate contract.
No future observations or evaluation gradients are introduced.

Optional imitation loss is request MSE plus a configured weight times MSE between
the actor's and teacher's counterfactual applied controls, both computed by the
existing adapter from the same causal previous controls. Recorded applied actions
remain dynamics targets. V4 supplies zero throttle and decisive braking inside a
relevant red/yellow light's 25 m legitimate-wait zone, with stationary hold; it is
a training label source only. Its performance remains an empirical question.

The objective is to reach a destination along a connected road route, with progress
reward and penalties for collisions, traffic violations, unsafe speed and discomfort.
CARLA supplies structured state initially. An observation-provider interface allows a
dedicated perception system to replace chosen fields later.

```mermaid
flowchart LR
    C[CARLA ground truth / future perception] --> A[Masked attention encoder]
    A --> P[RSSM posterior + recurrent memory]
    P --> S[SAC actor: steering, throttle, brake]
    C -. optional current structured observation skip .-> S
    S --> M[Shared action adapter]
    M --> C
    P --> R[Real latent replay]
    P --> I[RSSM prior: short imagined transitions]
    I --> V[Validation gate + separate synthetic replay]
    R --> Q[SAC twin critics and actor updates]
    V --> Q
```

Attention is part of the observation encoder. It learns relationships among ego,
objects, waypoints, traffic controls and weather through world-model prediction losses.
It does not produce a certified list of important objects or independently instruct
the policy. The decoder heads reconstruct structured state from RSSM latent features.
SAC learns driving decisions from reward, using those latent features.

This is an RSSM/SAC hybrid with short branched rollouts. It is not a reproduction of
Dreamer, PlaNet or MBPO: there is no planner, imagined actor backpropagation through
dynamics, ensemble, or benchmark-equivalence claim. The design uses the RSSM
[prior/posterior distinction](https://arxiv.org/html/1811.04551v5),
[short branched model rollouts](https://arxiv.org/abs/1906.08253), and
[SAC's off-policy entropy objective](https://arxiv.org/abs/1801.01290).

## 2. Files and responsibilities

| File | Responsibility and reason for separation |
| --- | --- |
| `config.py`, `config.json` | Typed settings, validation and explicit compatibility checks; JSON is editable and stored with outputs. |
| `schema.py` | One observation layout and normalizer shared by collection, models and deployment. |
| `geometry.py` | Coordinate conversion, line crossings, route progress and numeric-ID slot retention; independently testable. |
| `control.py` | The same action adapter in NumPy and PyTorch; weather speed/visibility rules. |
| `observations.py` | Oracle extraction, geometric visibility and replaceable perception contract. |
| `rewards.py` | Decision-rate task rewards and bounded comfort costs during live collection. |
| `environment.py` | CARLA session, traffic, pedestrians, synchronized stepping and task endings. |
| `data.py` | Complete NPZ episodes, metadata, whole-episode splits and masked sequence sampling. |
| `model.py` | Attention encoder, Gaussian RSSM, state/reward/termination heads and losses. |
| `sac.py` | Stochastic actor, twin critics, target networks, entropy coefficient and replay batches. |
| `training.py` | Supervised updates, checkpointing, prediction evaluation, gate and prior-only imagination. |
| `runner.py`, `__main__.py` | Collection, fitting, SAC training, evaluation, resume and orchestration. |
| `tests/` | Offline numerical, regression and integration checks; no CARLA driving. |

The existing CARLA build, image dataset and image-collection scripts are not part of
the RL data format. Image PNGs alone do not contain the aligned state/action/reward
sequences required to train this world model.

## 3. Coordinates and observations

The neural observation contains **114 continuous values**:
20 context values, five 2D route waypoints, and twelve objects with seven values each.
Presence masks and categorical labels are stored separately. No numeric actor ID is
passed to attention, the RSSM or SAC.

The frame is ego-relative: `x` forward and `y` left. CARLA's native lateral direction
is converted explicitly. Distances are metres, velocities m/s, accelerations m/s²,
and yaw rate radians/s. CARLA's yaw-rate sign and degrees/s are converted. Sun altitude
remains degrees because it is a weather parameter. Steering/throttle/brake are commands,
not measured wheel angles.

| Context indices | Fields | Purpose |
| --- | --- | --- |
| 0–4 | Forward/left velocity, forward/left acceleration, left yaw rate | Ego motion and comfort history. |
| 5–7 | Previous applied steering, throttle, brake | Causal control state and exact slew-limit context. |
| 8–10 | Signed lane offset, heading-error sine and cosine | Lane alignment without an angular wrap discontinuity. |
| 11–13 | Legal speed limit, cautious target speed, remaining route metres | Legal/cautious pace and destination progress. |
| 14–15 | Relevant traffic-light and stop-sign distance | Upcoming stopping geometry; explicit control-presence masks. |
| 16–19 | Precipitation, wetness, fog density, sun altitude | Weather/visibility context for caution. |

Five route points are sampled 5, 10, 20, 30 and 40 metres ahead along the static route,
then converted to ego-relative coordinates. Near the destination they clamp to the
route endpoint. These points expose upcoming turns without adding a map image or planner
to the learned policy.

Object slots are six vehicles and six pedestrians. Each contains forward/left
position, ego-relative velocity components, half-length, half-width and confidence.
Classes are vehicle, adult, child. Ground-truth confidence is 1.0. The fixed small
capacity bounds model cost; it does not describe every actor in town.

The highest-priority visible candidates retain numeric-ID slots. Disappeared or
lower-priority actors release their slots and newcomers fill free slots. Child candidates
receive priority, then distance, so a new child can displace a farther adult when full.
Occluded actors leave the observation; the RSSM can carry history across their absence.
This is oracle identity matching, not an implemented image tracker. Child labels use
CARLA's `age` attribute, with the documented child blueprint IDs as fallback for content
packs that omit age.

Light classes are none, unknown, red, yellow and green. Unknown/off/nonstandard light
states map to unknown rather than green. Absent values are finite zero sentinels with
masks. Objects use metadata ID `-1` when absent. IDs are never delta-regressed or hashed.
The presence/category heads model births, disappearances and light changes explicitly.

## 4. What “visible” and “cautious” mean

Ground-truth visibility is an explicit approximation of a forward sensor:

1. Actor centre must be ahead, within the configured horizontal field of view and range.
2. A CARLA ray from just ahead of the ego body to the target body centre must be clear.
3. Hits within the target's bounding radius are accepted as target geometry.

Default clear range is 70 m and field of view 100°. Effective range is
`max(10, 70 * (1 - 0.4*rain/100) * (1 - 0.7*fog/100) * night_factor)`,
where `night_factor = 0.5` below the horizon and otherwise 1.0.
This uses simulator geometry and a chosen degradation rule. It is not pixel-level
visibility, a rendered-image detector, or a calibrated human visibility model. Buildings
and other actors can block the ray; illumination and texture contrast are not measured.

A visible child activates caution within 30 m forward and 10 m lateral distance.
The target becomes at most **4.17 m/s** (about 15 km/h). This covers roadside children
as well as crossing children. It does not itself implement crossing prediction or a
stopping-distance guarantee.

Weather target speed is the legal limit multiplied by the strictest applicable factor:
0.7 for rain or wetness at least 20%, 0.7 for negative sun altitude, 0.5 for fog at least
20%. Factors take the minimum rather than multiplying the speed cap. Visibility reductions
do combine. Child caution can lower the target further. No speed target overrides SAC's
chosen action: inappropriate speed earns a penalty.

Child penalties allow reaction and braking: the permitted envelope initially equals
the speed at first sighting, then decreases at 2.5 m/s² after a one-second reaction
interval, down to 4.17 m/s. The penalty measures speed above that envelope. This avoids
punishing an unavoidable instantaneous speed change at first visibility. The cautious
target itself immediately informs the policy. The envelope resets when no nearby child
is visible; occlusion behavior still requires closed-loop evaluation.

## 5. Simulation, routes and scenario defaults

Town01 and the Tesla Model 3 are compact starting choices matching the existing launcher.
Random routes use connected road spawn pairs and CARLA's GlobalRoutePlanner at 2 m
resolution, with length 80–600 m. There are up to 100 random attempts to find a usable
route/spawn. Set both spawn indices for a fixed pair; fixed routes need connectivity
but are allowed outside the random-route length range.

Progress projects ego position onto a local route window, 8 m behind to 15 m ahead of
the previous progress. This avoids jumping to a later pass at an intersection. New
forward progress is rewarded only above the episode's previous maximum. Reversing loses
half a metre-equivalent per reversed metre; retracing an already rewarded section earns
no new progress. Success requires less than 3 m remaining and less than 4 m Euclidean
distance from the destination.

The default scene requests exactly 20 NPC vehicles and 20 pedestrians, with 35% children
(seven at these defaults). Spawn placement favours the route and nearby navigable sidewalks.
Vehicles use Traffic Manager; walkers use CARLA AI controllers at 0.8–1.8 m/s with a
20% pedestrian crossing factor. Missing assets or insufficient successful spawns fail
the episode setup with actual counts rather than silently making an easier environment.
Children/adults are required when pedestrians are enabled. Counts can be reduced explicitly.

Episodes cycle ClearNoon, HardRainNoon, ClearNight, HardRainNight and FogNight. This
provides coverage without a separate curriculum or weather scheduler. Seeds vary routes,
actors and controller noise. No quantitative weather balance in visible hazard encounters
is claimed; inspect event counts after collection.

CARLA rain appearance alone does not establish reduced tire grip. This wrapper explicitly
multiplies **ego** wheel tire friction by
`max(0.5, 1 - 0.35*rain/100 - 0.15*wetness/100)` once at spawn. NPC wheel physics are
unchanged. Ego and NPC vehicle lights are enabled. Rendering stays enabled so night/rain
are present in the simulator and future camera providers can attach sensors.

Physics ticks are 0.05 s with substepping up to ten 0.01 s steps. Each applied action
is held for two ticks, giving a 0.1 s control/transition interval (10 Hz). All action-repeat
ticks finish before the decision is evaluated, preserving a fixed learned transition
duration. Actor queries and visibility rays run once per decision rather than twice. Ego settles for ten unrecorded ticks with brake before reset observation.

An IMU stream supplies a frame barrier on every physics tick. A 20 ms default grace
for sporadic collision/lane callbacks runs once at the decision boundary, then events
from both ticks are drained and checked. Warm-up ticks also use the barrier/grace. Frame IDs are checked and detected late events reject collection.
A final grace/drain check runs before publishing a completed episode.
CARLA event streams have no explicit empty-event message; this bounded grace is not a
formal delivery guarantee. Timing and final-event behavior need live simulator verification.
Another ticking client or a mismatched world frame causes an error instead of mixed data.

## 6. Actions and traffic rules

SAC requests `[steering, throttle, brake]` in `[-1,1] × [0,1] × [0,1]`.
The adapter clips bounds and converts throttle-minus-brake to a signed longitudinal
command, eliminating simultaneous applied acceleration and braking. Steering changes
at most 2 command units/s. Signed longitudinal command changes at most 2.5 units/s
toward acceleration and 4 units/s toward braking. The result maps back to nonnegative
throttle/brake. NumPy execution and PyTorch imagination implement the same mapping.

Both requested and applied actions are logged. Dynamics use **applied** actions.
SAC critics use **requested** actions: their transition includes the adapter, and the
feature vector supplies previous applied controls. Actor entropy therefore describes
requests, not a density over the many-to-one applied-control mapping. This preserves
the agreed three-component interface without pretending its adapter is invertible.

Red-light penalties use CARLA stop waypoints and forward front-bumper crossings, limited
to the affected lane width. All cached light stop lines are checked for actual violations,
including when the policy leaves its planned route; the observation exposes the next
route-relevant light only. Cheap front-bumper crossing checks, stop dwell and light-state checks remain at each
physics tick (0.05 s), even though expensive visibility/observation queries run at 10 Hz.
State at the crossing tick determines red; yellow is represented
and obeyed by the bootstrap agent but is not counted as red-light running.

Stop signs use the route's entry into the trigger volume as a stop-line approximation,
or a projected trigger-centre waypoint for an off-route sign. A stop requires speed
below 0.3 m/s for one continuous second within 6 m before the line and the affected lane.
Crossing without that dwell incurs the penalty. This is an explicit project rule; it
does not claim CARLA leaderboard or jurisdiction-specific legal equivalence.

Crossing any marking whose type includes `Solid` is an illegal-lane event. Off-road
means no unprojected driving waypoint under the ego centre or lane-centre offset beyond
half lane width. Wrong-way means velocity against the nearest driving lane direction
by more than 0.5 m/s. These are centre/lane approximations, not wheel-level road occupancy.

## 7. Reward and episode endings

New collection computes rewards once per recorded decision, `dt=0.1 s` by default.
Task/safety costs remain explicit; comfort costs are bounded **rates per second**.
The plain reward version is `decision-comfort-v2`. The observation schema remains
`carla-structured-v1` because the observation fields did not change.

| Component | Default contribution per decision | Why |
| --- | --- | --- |
| New route progress | `+2 * new metres`, minus reverse adjustment | Dense incentive for destination travel. |
| Route success | `+100` once | Completion incentive; suppressed if collision occurs in the same interval. |
| Collision | `-100` once | Explicit failure cost; episode ends. |
| Red-light crossing | `-20` per detected crossing | Traffic-rule violation. |
| Stop-sign violation | `-10` per detected crossing | Traffic-rule violation. |
| Solid-marking crossing | `-3` per decision with an event | Illegal-lane penalty. |
| Off-road | `-10 * dt` | Departure penalty plus eventual task termination. |
| Wrong-way | `-5 * dt` | Penalize travelling against the lane. |
| Legal speeding | `-0.1 * dt * excess²` | Increasing cost above the legal limit. |
| Unsafe child speed | `-1 * dt * envelope_excess²` | Enforce the reaction/braking envelope described above. |
| Unsafe weather speed | `-0.5 * dt * weather_excess²` | Lower pace in rain/night/fog when the cap is below the legal limit. |
| Acceleration discomfort | `-0.1 * dt * B(abs(filtered_longitudinal_acceleration), 3)` | Allow moderate acceleration, cap the comfort cost. |
| Jerk discomfort | `-0.1 * dt * B(filtered_longitudinal_jerk, 5)` | Penalize abrupt acceleration changes without rewarding immobility. |
| Steering changes | `-0.05 * dt * min(1, (steering_rate/2)²)` | Discourage twitching while preserving the hard slew limit. |
| Time | `-0.05 * dt` | Discourage delay without a separate forward-speed bonus. |

Here `B(x,k) = min(1, max(0, x/k - 1)²)`. Acceleration is the ego-forward value
already stored in observation index 2. An exponential filter uses
`a_filtered += (1-exp(-dt/0.3)) * (a_measured-a_filtered)`, initialized from the
initial observation. Jerk is the absolute change in this filtered value divided by
the **recorded decision interval**, not a second differentiation of noisy physics-tick
samples. Acceleration/jerk units remain m/s² and m/s³. Steering rate is command units/s.
The time constant suppresses one-frame spikes; the GRU can retain the relevant history.

The three comfort costs together cannot exceed **0.25 reward/s**, or 45 over the
maximum default 180 s episode. A collision decision has zero comfort charge and resets
the comfort filter: the impact is already charged as a collision. This prevents a
collision impulse becoming tens of thousands of extra jerk penalty. Lateral acceleration
is not separately penalized; steering rate and the task/speed penalties are the compact
initial comfort design. These are tunable preferences, not physical comfort certification.

Weather and legal speeding can both apply when both constraints are broken. Safety
costs are not capped by the comfort ceiling. A collision can still leave a positive
whole-episode return if enough progress was accumulated first; the collision penalty
is explicit, not a claim that every failed route must have negative total return.

`terminated=True` for collision, route success or two continuous seconds off-road.
`truncated=True` for 1,800 decisions (180 s) or 60 continuous seconds stuck, with task
termination taking priority. Stuck means speed below 0.2 m/s and progress at most
0.01 m per decision without a legitimate wait. A red/yellow light exempts waiting only
when its line is **0–25 m ahead**. An unsatisfied stop exempts it only **0–8 m ahead**.
Controls already behind the bumper do not exempt waiting. Mere visibility of a child
requires caution but does not indefinitely reset the stuck timer. The overall time
limit always applies, including legitimate waits.

Only task termination suppresses SAC bootstrap. Time/stuck truncations and finite
imagined rollout horizons retain the final next-state value.

## 8. Data, splitting and normalization

Each complete episode is an NPZ containing `T+1` observations and `T` requested/applied
actions, rewards, end flags, event labels and reward components. Frame/time arrays also
have `T+1` entries. The final observation is captured before reset. Arrays are numeric;
loading disables pickle objects.

The JSON sidecar records the explicit schema version, complete config, collector and
policy update count, observation source, CARLA versions, seed, map, weather, start/goal,
static route points, actual actor/child counts, friction factor and outcome summary.
The dataset manifest stores feature names, conventions and the split seed. There are
no content hashes or hash-derived object, schema or route identifiers.

NPZ writes use a temporary file and replacement. Metadata is written before the final
NPZ commit marker. Existing episode names are never overwritten. An orphan sidecar is
reported for inspection. Validation checks dimensions, finite values, masks/classes,
action bounds and mutual exclusion, timing, reward-component totals, end flags, and
agreement between applied controls and next observation's control history, and
episode-constant weather. The dataset manifest and episodes require the explicit reward
version, so legacy raw-jerk labels cannot silently enter new training.

Each block of ten episode IDs receives a seeded shuffle of eight train, one validation
and one test assignments. Existing assignments never move when episodes are appended;
`splits.json` lists them. Sequences never cross episode boundaries or split boundaries.
Test episodes are excluded from model fitting, normalizer fitting, SAC replay and the
imagination gate. Explicit final prediction evaluation can read them.

Means/scales are fitted only on valid continuous values in training episodes. Absent
objects/control distances do not contribute. Object statistics are shared across slots
so physical scaling is consistent. Dimensions with tiny/unseen variance use scale 1.0
instead of amplifying noise. The fitted normalizer is saved and stays fixed during SAC
and subsequent world-model refreshes; changing it would change the model's input/output
coordinate system.

Half of joint world-model sequence draws select task-ending windows, including
collision, off-road termination and successful arrival. The existing config name
`failure_sequence_fraction` is retained for compatibility, but its tail pool now includes
all `terminated=True` episodes; time/stuck truncations remain negative. The other half
sample episodes uniformly, then contiguous windows. If no task endings exist, all draws
use the ordinary sampler. This oversampling is useful for learning rare dynamics, but
its probabilities are biased. A separate final termination readout fit restores natural
training class priors as described below. Validation/test data are never resampled. Default windows
are five burn-in plus twenty supervised decisions. Short episodes are padded, with
padding completely excluded from loss. Their burn-in shrinks so even a one-transition
collision receives supervision. Burn-in starts a window with zero memory and is an
approximation; SAC real replay instead reconstructs the full history from episode start.

## 9. Attention and RSSM equations

There are 21 tokens: ego, route summary, weather, traffic controls, five waypoints and
twelve objects. Each projects to 64 dimensions. Type embeddings distinguish their
roles; waypoint embeddings preserve along-route order. Object class embeddings expose
child/adult/vehicle distinctions. Object slot-position embeddings let the decoder
reconstruct the assigned tracked slots; they do not contain actor IDs. Absent object
keys are masked, and the ego token is always present to avoid all-masked attention.

A four-head ego query attends to scene tokens, followed by residual connections,
LayerNorm and a two-layer ELU feedforward block of width 128. Only the ego-context
encoding is returned. One compact attention block bounds cost; a large transformer
stack or separate attention decoder is unnecessary for this first structured-state system.

The RSSM has deterministic memory `h` of size 128 and Gaussian stochastic state `z`
of size 32:

```text
e_t = attention(o_t)
h_(t+1) = GRU([z_t, applied_action_t, normalized_known_weather_4], h_t)
p_(t+1) = Normal(prior_net(h_(t+1)))
q_(t+1) = Normal(posterior_net([h_(t+1), e_(t+1)]))
```

The posterior incorporates the actual current observation during collection/inference.
The prior uses no future observation and generates imagination. Initial `h` is zero;
the initial posterior encodes the reset observation. Network standard deviations use
`softplus(clamped_raw_std)+0.1`, avoiding zero variance or unstable scales.

Prior/posterior and decoder heads are two-hidden-layer ELU MLPs of width 256. Heads
predict absolute normalized continuous state, object/control presence, object classes,
light category, reward and task termination. Absolute state reconstruction is deliberate:
ego-relative coordinates rotate, and objects can appear/change slots. Blind continuous
deltas would give identity changes an incorrect motion interpretation. Categorical
fields are classification targets, never continuous deltas.

For an active sequence step:

```text
L = reconstruction(q state)
  + 0.5 * reconstruction(sampled prior state)
  + Huber(prior_reward, real_reward)
  + BCE(prior_mean_termination, real_terminated)
  + 0.1 * max(balanced_KL, 1 nat)

balanced_KL = 0.8 * KL(stop_gradient(q) || p)
            + 0.2 * KL(q || stop_gradient(p))
```

Applied-control and fixed-weather decoder dimensions are excluded from reconstruction
MSE because their update is known exactly. Reconstruction averages the remaining
masked normalized MSE over four groups (ego, other context,
waypoints, objects), then adds object/control presence BCE, masked object-class cross
entropy and light cross entropy. Group averaging prevents numerous object coordinates
from swamping ego/route learning. Class losses apply only to present objects. Reward/end
heads train on prior features so their targets cannot depend on observing the future.
The termination readout uses `[h_next, prior.mean]`; sampled prior state still drives
state reconstruction/reward and latent imagination. Validation and imagination use the
same mean-latent termination input, avoiding a sampled-versus-mean readout mismatch.
Balanced KL teaches both inference and prediction while the free-nat floor limits
pressure toward latent collapse. A direct prior reconstruction term strengthens
action-conditioned prediction beyond posterior reconstruction alone.

Adam uses `3e-4`, batch 32 and global gradient norm clipping at 100. Training samples
latent states; online/real-replay inference uses posterior means for repeatable features.
Imagination samples the prior. These are design choices for a small implementation;
Gaussian spread is conditional stochasticity, not an epistemic uncertainty estimate.

Attention is batched over all sequence frames before the recurrent loop. Reconstruction
heads/losses are batched over active timesteps afterward. The GRU still evolves in
causal order. Full-history replay encoding batches up to 16 independent episodes;
attention runs in chunks of 2,048 frames to bound temporary memory, then the recurrent
scan advances all episodes together. Episode boundaries remain separate and complete
history is retained. Numeric episode IDs cache encodings only within one integer model
version; changing model weights clears the cache. Replay cache keys do not use
file/object content hashes. Separate experiment audits hash artifacts for preservation.

After joint fitting, the world-model body is fixed while its termination head is
refitted for **2,000 updates** by default. This extra stage addresses the observed gap
between very low sequence-window event loss and poor full-history held-out detection.
It does not refit dynamics, attention, the reward head, normalization or SAC.

1. Reconstruct every real training episode from its actual initial observation using
   posterior means, exactly as real replay and validation do.
2. Apply each recorded action to that history and cache `[h_next, prior.mean]`.
   Every real transition is eligible, including successful endings and ordinary
   nonterminal states far from endings. Validation/test labels are excluded.
3. Draw half a minibatch uniformly from positive task endings and half from negative
   transitions. Optimize only the existing termination MLP using BCE and fresh Adam
   moments. No future observation is supplied to these action-conditioned inputs.
4. Restore the natural **training** event prior with a saved logit offset:

```text
pi_real = positive_training_transitions / all_training_transitions
pi_sample = positive_draws / minibatch_size
corrected_logit = balanced_logit + logit(pi_real) - logit(pi_sample)
p_termination = sigmoid(corrected_logit)
```

Uniform sampling within each class preserves its feature distribution; this is the
class-prior correction for the intentional class-balanced sample distribution. It is
not a threshold adjustment or a promise that the neural classifier generalizes. The
threshold remains 0.5 and held-out precision/recall/Brier requirements are unchanged.
A single held-out collision provides little statistical confidence even if detected.
More diverse real event data may still be required.

The fitted offset is a non-trainable saved scalar. Older format-2 checkpoints load
with their previous implicit offset of zero, so the user's completed dynamics fitting
is reusable. Subsequent joint fitting resets this offset for its auxiliary sequence
loss, then refits the calibrated readout before validation. Old joint-optimizer moments
for the separately refitted head are cleared. `termination_updates` is logged separately
from full `model_updates`. The explicit `fit-termination` command performs just this
readout stage and writes a new checkpoint, preserving the source. Routine initial fits
and model refreshes include it automatically. Missing positive/negative training classes
are reported; this does not bypass held-out quality gates.

## 10. SAC, replay and model refresh

SAC receives `[h_128, z_32, normalized_known_weather_4, previous_applied_action_3]`,
**167 values**. Explicit controls keep adapter state exact. Weather stays exactly the
recorded episode context in real replay and imagination, and also conditions the GRU.
The decoder cannot silently turn rain into clear weather for the next actor decision.
Actor and both critics use two 256-wide ELU hidden layers. The actor emits means and
log standard deviations for three Gaussian requests, then tanh-squashes and scales
throttle/brake to `[0,1]`. Log probabilities include the tanh Jacobian and scaling.
Log standard deviations clamp to `[-5,2]` for finite exploration scales.

The critic target and actor objective are:

```text
y = reward + gamma * (1 - terminated) *
    (min(target_Q1, target_Q2)(next_features, next_request) - alpha * log_pi(next_request))
L_Q = MSE(Q1, y) + MSE(Q2, y)
L_actor = mean(alpha * log_pi(request) - min(Q1, Q2)(features, request))
```

Critics do not train the world model. Replay/generated features are detached. Critics
are frozen while computing actor gradients. Adam is `3e-4`, batch 256, `gamma=0.99`,
and target Polyak coefficient `tau=0.005`. Initial `alpha=0.1` is learned with target
entropy `-3` in request coordinates. Critic gradient norm clips at 100. Gamma 0.99 at
10 Hz favours roughly a ten-second discounted horizon; change it deliberately if longer
credit assignment is needed.

Bootstrap collection defaults to twenty episodes, alternating BasicAgent and a noisy
controller. Noise standard deviations are 0.06 steering, 0.12 throttle, 0.05 brake;
3% of decisions request a broad random action. This supplies off-nominal controls
without a separate learned baseline. The agent follows the chosen route and uses
the cautious speed target; its own avoidance/light logic supplies normal driving data.
It does not create guaranteed rare-event coverage.

After 10,000 initial joint model updates, 2,000 termination-head updates and a passing
validation gate, the default policy
budget is **100,000 SAC optimizer updates**. Training alternates:

```text
10,000 SAC updates using saved real replay + validated imagination (no CARLA connection)
2 CARLA episodes driven by the current SAC actor (no weight updates during an episode)
close CARLA session / destroy this session's actors / restore simulator settings
200 joint world-model updates on real training episodes
2,000 termination-only updates on full-history training features (dynamics fixed)
increment model version; rebuild real/synthetic replay; validate the fixed suite
repeat until the optimizer budget is reached
```

There is no final collection block once the requested update budget has been reached.
Thus 100,000 updates require 18 interleaved policy episodes at these defaults. Bootstrap
is additional for a fresh dataset. `--episodes N` remains an explicit real-collection
budget; it uses the same update blocks before collecting each group. `--episodes` and
`--policy-updates` cannot be combined. The default path uses the optimizer budget, not
an implicit thousand simulator episodes. Setting collection count to zero permits
saved-replay-only training with the same validated mixed replay, useful when CARLA is off.
Only explicit `--episodes N` selects a real-episode budget; configuration has no
ambiguous second episode budget.

At least 500 real **training-split** transitions are required before SAC. All simulator
interactions, including held-out collection, count toward logged real steps. Networks
train while CARLA is disconnected; no actor pool or background ticking process is added.
Spawning/destroying actors remains normal for actual new episodes, but does not happen
during neural update blocks. Reusing recorded real replay also needs no simulator.

Real replay retains recent whole train episodes around a 100,000-step cap, allowing
one boundary episode beyond that cap to preserve its history. Model refresh changes
representations, so all retained histories are re-encoded under the new version. The
fixed normalizer is reused. Old synthetic data is discarded. Between weight changes,
encoding caches avoid repeating unchanged histories. SAC weights are retained across
gradual refreshes; re-encoding removes stale coordinates but cannot eliminate all
optimization effects of representation drift. Migration starts SAC afresh because old
reward targets and the explicit feature layout changed.

Synthetic rollouts are regenerated every 100 SAC updates to follow the changing actor,
not just once per 10,000-update block. Checkpoints every 1,000 updates bound lost compute.
Those intervals balance small replay/serialization overhead against sample freshness
and recovery; they are configurable research defaults, not convergence guarantees.

### Optional actor warm start and current prototype variant

`train --model` always creates fresh SAC state. Optional supervised actor warm-up
does not import an older policy. On training-only demonstrations it minimizes
deterministic request MSE plus `0.01 * MSE(log_std_output, -3)`, leaving critics and
world model fixed. These updates do not increment SAC's update counter. During SAC,
an optional demonstration anchor adds request MSE with its configured weight; the
actor's Q term is normalized to `2.5 * Q / mean(abs(Q)).detach()` when anchored.
The critic targets and temperature updates retain their SAC definitions.

The optional structured skip adds continuous114, presence12, masked class indicators36,
control masks2 and light one-hot5: 169 values, or 336 total policy/critic features.
It is inserted before the trailing three applied controls. Live/real replay uses the
current observation; imagined replay uses predicted continuous fields/masks/classes/
light and causally propagated weather/applied controls. It never reads future CARLA
state during imagination.

Recorded labels come from training autopilot episodes or separate DAgger labels.
Geometric v1/v2/v3 teachers use current training observations for pursuit and speed
targets; v2 corrects measured steering calibration and v3 adds stationary hold-brake.
None is a driving-time override. Default sampling balances manoeuvres with uniform
states. Traffic-focused sampling can additionally separate moving red/yellow braking
approaches from long stationary waits. The current optional object permutation moves
current skip geometry/masks/classes together while retaining latent history, context,
actions and teacher labels; it affects demonstration fitting only and is untrained.

Candidate 008 uses 50,000 warm-up updates, anchor weight 100, initial alpha 0.001,
geometry_v3, the skip, traffic fraction 0.5 and 2,000 SAC updates. It reuses a frozen
attention/RSSM/reward model with a training-only refitted termination head. Collection
and model refresh are zero, so the general interleaved schedule above does not run in
this candidate. This is an explicit experimental variant, not the package defaults.

## 11. Validation and imagination

Routine validation uses a fixed list of the first up to ten whole validation episodes.
The IDs are saved with checkpoints and kept across training refreshes/resume. Selection
is by episode order, never by failure labels; every transition in these episodes enters
event metrics at its natural frequency. An explicit fit selects the bounded suite again
so added validation data can supply more support. Explicit `evaluate-model` uses the
whole requested split for full event evaluation.

For each model version, held-out validation histories initialize posterior states.
Recorded applied actions then drive prior-only open-loop predictions at horizons
1, 3 and 5 (0.1, 0.3, 0.5 s by default). Up to 128 uniformly chosen branch starts are
used for continuous/reward metrics. There is no teacher forcing inside a rollout.
Metrics include context MAE in physical units, wrapped heading error, normalized
RMSE, cumulative reward MAE/bias, presence Brier score and class/light accuracy.
Known previous controls and episode-constant weather are carried exactly when
evaluating decoded state and excluded from prediction RMSE. Their context MAEs are zero
by construction; this is declared in each report, not claimed as learned accuracy.

Termination Brier score, precision, recall and TP/FP/FN/TN counts use every held-out
decision, retaining the natural class frequency. Probability threshold, logit offset
and input convention are declared in the report. Counts of positive/negative terminations and real collision
events are reported. No collision labels means collision modelling remains explicitly
unvalidated. The termination head combines success/off-road/collision task endings;
aggregate termination accuracy does not establish collision-specific recall.

For every actual held-out ending, `termination.endings` reports its probability,
episode/transition, reason/weather, pre-action visible-object count and number of
nonterminal transitions scoring at least as high. This ranking describes discrimination;
it is not used to select a threshold. Labels and object counts are reported only after
prediction, never supplied as future information to the model. The checkpoint's last
head-fit training metrics accompany validation and persist through agent checkpoints.
The gate distinguishes insufficient label support, a head that has not fit training
endings, and a head that fits training endings but fails held-out data. For the latter,
it recommends better event/observation coverage and joint fitting instead of another
identical readout fit. Gate criteria, inference and optimization are unchanged.

The current forward object representation excludes static obstacles and out-of-view
actors. No collider identity is recorded. An empty pre-collision object set therefore
flags a possible input limitation; it cannot establish what was hit or prove an
unavoidable observability failure. New compatible observations/data would be required
if a relevant hazard cannot be represented.

Default gate at the configured imagination horizon requires:

| Criterion | Starting tolerance |
| --- | --- |
| Normalized continuous RMSE | ≤ 0.75 |
| Forward speed MAE | ≤ 2 m/s |
| Lane offset MAE | ≤ 0.5 m |
| Wrapped heading MAE | ≤ 0.2 rad |
| Cumulative reward MAE | ≤ 10 reward units |
| Termination Brier score | ≤ 0.2 |
| Termination recall at probability 0.5 | ≥ 0.5 |
| Termination precision at probability 0.5 | ≥ 0.5 |
| Positive / negative termination support | ≥ 1 / ≥ 20 |

These thresholds are editable research starting points. Set/freeze appropriate
tolerances using pilot validation data before final test evaluation. Passing this gate
is not proof of safe driving, rare-event generalization, or well-calibrated uncertainty.
No unsupported claim about attention weights or Gaussian variance replaces evaluation.

When enabled, 1,024 nonterminal real replay states initialize synthetic rollouts.
The actor requests an action, the common adapter computes applied control, and the
RSSM prior samples the next latent state and predicts reward. The calibrated ending
head reads the same action-conditioned prior mean used during its final fitting and
validation; a Bernoulli draw from that probability supplies the synthetic ending flag. Rejected transitions are omitted, with no
invented terminal flag. Nonfinite predictions, decoded forward speed beyond ±50 m/s,
or decoded remaining distance outside `[-5, upper_bound]` are rejected. The upper bound
is the larger of `max_route_metres+50` and training mean remaining distance plus six
normalizer scales plus 50 m, accommodating longer explicitly fixed routes. These
are numerical/physical sanity checks, not uncertainty detection.

Default horizon is one. Config supports three/five for deliberate validation-backed
experiments. The horizon limit does not set `terminated`. Synthetic replay is separate,
version-labelled, and replaced every 100 updates or after any model change. SAC samples
75% real and 25% synthetic transitions, with a configurable positive synthetic fraction
limited to 50%. Actual integer minibatch counts are logged. A failed gate stops SAC
and automatic policy collection with an actionable report. Zero accepted synthetic
transitions also stop training. There is no silent real-only fallback or baseline mode.
More data or fitting may still be required; the implementation does not weaken the gate
to manufacture a pass. Quality stops use a specific exception and a clear CLI exit
(code 2) with report/checkpoint paths, without a Python traceback. Unrelated programming
errors still propagate normally.

No future CARLA observation is read during imagination. Latent recurrence propagates
learned route/object/traffic-control context over the short horizon; known weather
and applied-control context are propagated explicitly;
the physical decoder is not fed back as a new measured observation. Long-horizon
route consistency and object identity after occlusion are not guaranteed.

## 12. Checkpoints, reproducibility and metrics

Checkpoints contain explicit schema/config, world-model weights, fixed normalizer,
world-model optimizer/update count, termination-head update count and prior-correction
scalar, and integer representation version. Agent checkpoints
also contain actor, twin critics, targets, all SAC optimizers, entropy coefficient,
policy update count, next episode ID, real interaction count, completed policy episodes,
updates within the current block, remaining collection episodes, pending refresh state,
fixed validation episode IDs,
Python/NumPy/PyTorch RNG states and the active NumPy generator state. Atomic replacement
preserves the previous complete checkpoint if interrupted before replacement.

Environment, reward and model configs must match the dataset/checkpoint. Resumed SAC
also checks training settings except device and additional budgets. Checkpoint format
2 and explicit reward version reject incompatible runs; collect a new dataset for changed contracts. There are
no checkpoint hash comparisons. Dataset import uses recording-content checksums for
deduplication. Explicit `--allow-scenario-variation` permits town/weather/traffic/routes
and connection settings to change while preserving ego, physics/timing, action,
observation, termination and reward contracts. This mode requires held-out support
for every training scenario, includes all validation episodes and gates each scenario
separately. `fit --warm-start` retains source weights, normalizer and optimizer,
jointly fine-tunes on the combined training split and refits termination, saving a
new world-model checkpoint. See COLLECTED_TRAINING.md for data and commands.
A normal resume recreates latent replay from raw episodes and
resumes its saved optimizer/collection phase; it cannot restore the simulator halfway
through an episode.
CARLA physics/navigation/traffic are not guaranteed bit-identical under repeated seeds.

Logs include route completion/success, return, distance, travel time, terminal reason,
event decision counts, collisions per kilometre with distance exposure, mean absolute
lane/heading error, acceleration, jerk and steering-rate measurements. Event decision
counts are samples containing an event, not universally unique incident counts. Policy
updates, model updates, real interaction count, representation version, generated/accepted
synthetic count, applied synthetic fraction, gate reason and wall timings are recorded.
Stages distinguish neural updates, collection and model refresh. Reset/drive, fitting,
encoding, validation, imagination and checkpoint durations expose bottlenecks. Throughput
and policy-compute ETA use observed optimizer-block timings; future simulator collection
and model-refresh costs are excluded from that ETA. World-model logs report every 100
updates plus the last one, reducing per-update filesystem overhead.

Final policy evaluation uses deterministic actor means and seeds offset by 100,000.
Its routes/weather/actors are repeatable scenario choices under the same config and
seed sequence. No evaluation results are used automatically to tune training. The
implementation does not claim sample-efficiency improvement without the user's experiments.

## 13. Integrating a dedicated recognition model later

Configure `environment.observation_provider = "my_perception:make_provider"`.
The provider owns its extra sensors, waits for the current `env.frame`, and returns
an `Observation` with the exact schema. A minimal integration shape is:

```python
class Provider:
    source = "image_model_objects+CARLA_ego_route_weather_controls"

    def __init__(self, env):
        self.env = env

    def reset(self):
        # Attach camera; initialize detector, metric-depth estimator and tracker.
        ...

    def observe(self, env, oracle):
        # Copy oracle arrays, retain only the deliberately declared ground-truth groups.
        # Replace objects/presence/classes/IDs with synchronized metric predictions.
        # Preserve actual applied control history at continuous[5:8].
        ...
        return predicted_observation

    def close(self):
        # Stop/destroy this provider's sensors.
        ...

def make_provider(env):
    return Provider(env)
```

The factory is an extension contract, not an included image detector. Predictions must
include metric relative positions/velocities, child/adult class, confidence and stable
slot assignment; bounding boxes alone are insufficient. Use simple incrementing tracker
IDs if needed; there is no requirement to hash objects. Lane/control estimates may also replace declared fields. This version deliberately
retains fixed simulator weather and actual applied controls; dynamically estimated
weather would require revising the known-context contract before using imagination.

For custom providers, the actor's cautious speed target is recomputed using the returned
object predictions. It cannot silently retain the oracle child-caution target. Rewards
and violations still use an independent oracle extraction, so a missed detection is not
mistakenly rewarded as safe. Build a new dataset/checkpoint for the changed observation
source; the compatibility check makes that change explicit. The custom provider must
avoid mutating oracle arrays while creating its observation.

## 14. Deliberate scope and remaining evidence

Only the requested structured attention/RSSM/SAC pipeline, CARLA task, data/checkpoint
support, prediction gate and evaluation commands are implemented.
There is no baseline learning mode, PPO, ensemble, uncertainty penalty, MPC, online
detector training, pixel decoder, actor pool, hosted dashboard,
experiment service or broad benchmark suite. Automatic early stopping is omitted;
update budgets, quality gates and held-out reports are explicit.

Offline tests establish numerical/interface behavior and saved-data reward calibration.
Live collection, fitting and development rollouts are recorded in PROTOTYPE.md and
VALIDATION.md. Candidate 007 achieved only 5/10 development arrivals and ran ten red
lights. The frozen model passes existing aggregate gates but misses all three held-out
collision endings. These results do not establish safe driving, transfer or sample
efficiency. The final fixed 50-episode acceptance evidence remains missing.

Fresh `run` invocations require a new or empty output directory and collect a new
dataset before fitting a randomly initialized world model and SAC policy. `fit` always
initializes its model, optimizer and training-only normalizer from scratch. Only explicit
`--resume` continues an interrupted SAC run with its complete checkpoint state.

Before initial fitting, fixed training and validation splits must contain enough real
task-ending and nonterminal labels. Missing support stops before model allocation or
gradient updates and writes a `.coverage.json` report. Time-limit/stuck truncations
remain nonterminal for this check. Collection budgets are fixed in advance; episodes
are never reassigned or selected by their outcomes to satisfy support requirements.
