# Town01 prototype: changes, model operation and reproduction

Updated 17 October 2026. This is the implementation and experiment record for the
Town01 work. The earlier prototype branch was paused; the new
`runs/town01_experiment_001` request is active, with fresh-model/fresh-SAC provenance,
an unchanged reserved final plan and a shared five-hour training limit. Its current
settings and evidence are in that experiment's manifest and COMMANDS.md. Historical
results below describe the older prototype branch. No candidate has demonstrated
the requested final result: at least 40 successes and at most 5 collision episodes
over 50 fixed episodes, ten in each of five weathers. No final 50-episode run has
been performed. Development results must not be presented as that result.

The fresh experiment has now completed 20,000 CUDA model updates and an explicit
training-only factorized event-readout recovery. The fixed suite and full
29-episode validation split pass the original aggregate gates, while all five
full-split collision endings remain missed. Fresh seeded SAC initialization is
verified exactly; 100,000 training-only warm-up updates are complete and CPU SAC
is using 25% model-generated replay under the original deadline. Current evidence
and limitations are in `runs/town01_experiment_001/MODEL_GATE_RESULTS.md`; final
driving performance remains unmeasured.

## 1. Artifacts and measured results

Paths below are relative to the repository root. The principal files are:

| Artifact | Meaning |
| --- | --- |
| `runs/manual/data` | Original 104 episodes; preserved with their original splits. |
| `runs/manual/world_model.pt` | Earlier fitted world model used as the reusable source. |
| `runs/manual/agent.pt` | Original resumed agent whose refreshed model failed validation. |
| `runs/town01_prototype_001/world_model.pt` | Reused attention/RSSM/dynamics/reward/normalizer with a training-only termination-readout refit. Source for later fresh SAC policies. |
| `runs/town01_training_data_001` | Isolated dataset containing the original 104 episodes plus 20 new labelled collection episodes. |
| `runs/town01_collection_001/data_audit.json` | Recording preservation, split, coverage and reserved-seed audit. |
| `runs/town01_prototype_007/development_evaluation.json` | Complete development results for the stop-hold teacher. |
| `runs/town01_prototype_008/agent.pt` | Latest trained SAC candidate; not an accepted final prototype. |
| `runs/town01_prototype_008/config.json` | Exact candidate training/environment/model settings. |
| `runs/town01_prototype_008/validation.json` | Fixed held-out world-model report used before its training. |
| `runs/town01_prototype_008/checkpoint_audit.json` | Frozen model tensor equality, gate result, training counters and initialization provenance. |
| `runs/town01_prototype_008/development_evaluation.json` | Latest development results, written after each episode; inspect `complete`. |
| `runs/town01_prototype_008/action_generalization_audit.json` | Read-only action/slot-order diagnostic; contains its reproduction source. |
| `runs/town01_prototype_008/final_plan.json` | Reserved 50-episode plan, not yet executed. |
| `runs/town01_prototype_progress.json` | Operational progress notes; result JSON and live processes are authoritative if this file is stale. |

Each experiment has `experiment.json`, configuration, source snapshots/hashes and
commands. `source/` records training source; `evaluation_source/`, where present,
records evaluation source. The whole worktree is not a clean committed baseline;
unrelated CARLA/build edits must not be attributed to these policy experiments.

| Experiment | Change | Driving evidence |
| --- | --- | --- |
| `001` | Frozen reusable model; fresh latent-only SAC; 10,000 actor warm-up updates, anchor weight 10, 2,000 SAC updates | 0/10 successes, 10 collision episodes. Rejected. |
| `002` | Current-observation skip; 50,000 warm-up updates, anchor weight 100, initial alpha 0.001; 2,000 SAC updates | 2/10 successes, 7 collision episodes, 1 timeout; 6 red-light violations. Rejected. |
| `003` | Prepared expanded-data recorded-label variant | Not trained. |
| `004` | `geometry_v1` labels on original training states | Trained; not driving evaluated after steering calibration was found inaccurate. |
| `005` | `geometry_v2`, measured Tesla steering calibration | 3/10 successes, 6 collision episodes, 1 timeout; 5 red-light violations. Rejected. |
| `006` | `geometry_v2` on expanded training data | One diagnostic episode: success, no collision, 1 red violation. Not a development/final benchmark. |
| `007` | `geometry_v3`, explicit stationary hold-brake | 5/10 successes, 1 collision episode, 4 timeouts; 10 red violations in 7 episodes. Rejected. |
| `008` | Same as `007`, plus 50% traffic-focused demonstration sampling | 4/10 successes, 1 collision episode, 5 timeouts; 11 red violations in 7 episodes. Failed the target. Its previously started evaluation finished during this documentation update. |

Object-order augmentation is implemented in the current source but was added **after
008 was trained**. No checkpoint has been trained with it enabled. No `009`
training was launched. Its passing offline tests are not driving evidence.
No training or evaluation job remains live. Traffic-focused sampling did not fix the
measured red-light problem. The following are development results, two episodes per
weather, not final acceptance evidence:

| Weather | 007 arrivals / collision episodes | 008 arrivals / collision episodes | 008 red violations |
| --- | --- | --- | --- |
| ClearNoon | 1/2 / 0 | 1/2 / 0 | 2 |
| HardRainNoon | 1/2 / 0 | 1/2 / 0 | 3 |
| ClearNight | 1/2 / 1 | 1/2 / 0 | 2 |
| HardRainNight | 0/2 / 0 | 0/2 / 0 | 1 |
| FogNight | 2/2 / 0 | 1/2 / 1 | 3 |

### World-model evidence

The fixed validation episodes are `8, 14, 22, 30, 43, 59, 63, 76, 86, 91`:
three successful endings, three collision endings and four time-limit truncations,
with 11,880 transitions. These split assignments were not changed.

| One-decision metric | Measured | Existing gate |
| --- | --- | --- |
| Normalized state RMSE | 0.582123 | <= 0.75 |
| Reward-sum MAE | 0.399445 | <= 10 |
| Forward-speed MAE | 0.889849 m/s | <= 2 |
| Lane-offset MAE | 0.109471 m | <= 0.5 |
| Heading-angle MAE | 0.022299 rad | <= 0.2 |
| Termination Brier score | 0.000309 | <= 0.2 |
| Termination recall | 0.5 | >= 0.5 |
| Termination precision | 0.75 | >= 0.5 |

Termination counts are TP=3, FP=1, FN=3. **All three held-out collision endings
were missed.** The aggregate termination gate passes because success endings also
count as task terminations. This is a known model limitation, not proof of collision
prediction quality. One-step route-remaining MAE is about 78 m and light-distance
MAE about 10.1 m; the existing gate has no separate bound for those fields. Long
imagined planning is not established by this report.

## 2. Changes made and why

| Area/files | Implemented behavior and reason |
| --- | --- |
| `config.py`, `__main__.py`, `runner.py` | Separate fresh `run`/`fit`, fresh SAC via `train --model`, and explicit same-run `--resume`; reject incompatible configuration/frontier reuse and occupied outputs. Removed obsolete checkpoint-import/conversion/reward-relabel paths. |
| `data.py`, `schema.py` | Numeric T+1 observations/T actions, masks, identities as metadata, fixed seeded whole-episode splits, train-only normalization, action/frame/reward checks, immutable saved episode paths. |
| `environment.py`, `geometry.py`, `observations.py`, `control.py` | Synchronous 0.05 s physics and two ticks per decision; routed observations, tracked object slots, control-line association/crossings, frame barriers and delayed-event checks; shared action clipping, slew limits and exclusive longitudinal application. |
| `rewards.py` | Versioned `decision-comfort-v2` reward and filtered comfort costs. Later prototype experiments retained these weights; red-light cost has not been increased. |
| `model.py`, `training.py` | Masked attention/RSSM, causal prior/posterior losses, train-only sequence fitting, termination-head calibration, full-history replay encoding/cache and unchanged held-out quality gates. |
| `runner.py` diagnostics | Coverage checks before fitting, specific failure/recovery messages, per-ending/per-episode false-alarm diagnostics; no automatic weakening or real-only fallback. |
| `sac.py` | Fresh actor warm-up from training demonstrations, optional continued behavior-cloning anchor during SAC, manoeuvre-balanced sampling and normalized Q scale when anchoring. |
| `policy.py` | Optional 169-value structured-observation skip beside latent features; imagined skips come from model predictions and causal known quantities. |
| `teachers.py` | Explicit versioned training-only geometric labels; steering calibration correction in v2 and zero-target hold correction in v3. Earlier versions retained for reproduction. |
| `runner.py`, `data.py`, `sac.py` | Labelled DAgger-style collection: per-step expert/policy mixture, separate expert labels, measured executed actions retained for model/Q learning. |
| `config.py`, `environment.py` | Ground-truth-only no-rendering option, restoring prior world settings on close; viewport toggle excluded from dynamics compatibility checks. |
| `evaluation.py`, `runner.py`, CLI | Fixed plans, incremental results, per-weather/episode collision metrics and exact 50-episode acceptance check. Optional protected traces cannot enter training replay. |
| `evaluation.py` | Red violation totals, violating episodes and rates overall/per weather, so route success does not conceal traffic violations. |
| `sac.py`, config/runner | Traffic-focused demonstration sampling, including moving approaches separately from long stationary red waits; used in candidate 008. |
| `policy.py`, `sac.py`, config/runner | Optional training-only object-slot permutation; geometry/mask/class move together within vehicle/pedestrian groups. Disabled by default and untrained so far. |
| `viewer.py`, `telemetry.py`, attention API | Passive chase view and actual structured state/reward/attention telemetry. Viewer does not tick or drive. Attention weights are diagnostic, not a causal safety explanation. |
| Launchers/tests/docs | Fresh/recovery shell workflows, artifact-preservation tests, numerical/integration checks and recorded experiment provenance. Latest full suite: 90 passed on host. |
| `graphify-out/` | Knowledge graph refreshed after project code changes. Existing C++ parser warnings mean it is a navigation aid, not an independent correctness proof. |

### Data added and preserved

The original 104 episodes had 83 train, 10 validation and 11 test episodes. The
isolated copy preserves their NPZ bytes and copied JSON/splits. Its old NPZ files
were hardlinked, so they must never be edited in place. New collection added IDs
104–123: 17 train, 2 validation, 1 test, giving 100/12/12 episodes total. The extra
collection had 5 successes, 9 collisions and 6 timeouts under a 50% per-step expert
mixture; those are **not autonomous policy results**. All 208 original NPZ/JSON
files and 208 isolated old files were checked unchanged in the data audit.

Only train episodes supply gradients/demonstrations. The fixed first-ten validation
suite remains the one above; newly appended validation episodes do not silently
replace it. Development/final scenario seeds are disjoint from collection. Protected
evaluation traces have `split: evaluation` and `usage: evaluation_only_never_train`;
dataset save/load rejects them. Collision observers recorded diagnostic provenance
without driving/ticking; several collection crashes involved stopped lead vehicles.

### Original training interruption

The manual agent had 180,000 SAC updates and a refreshed model at 13,600 joint model
updates. Its saved normalized RMSE was 0.846175, exceeding the unchanged 0.75 gate.
The report TP=3/FP=0/FN=0 only described termination, not continuous prediction.
Thus it could run earlier episodes and later stop after a model refresh/new coverage.
Resuming that same failed checkpoint does not repair it. The prototype branch reused
the earlier compatible `world_model.pt`, refit its termination readout on training
data, and started SAC afresh; it did not reuse the failing actor/critics.

## 3. How the world model functions now

The default provider is CARLA ground truth filtered by geometric visibility. It is
not a trained camera detector. One observation contains 114 continuous values,
12 object presence masks/classes, two control masks and a five-class light state.
IDs are logging/tracking metadata and never network inputs. Continuous units are
metres, seconds and radians, in an ego-relative forward/left frame.

1. Normalize using fixed training-set statistics; mask absent fields.
2. Build 21 tokens: ego, route summary, weather, traffic controls, five route
   waypoints, six vehicle slots and six pedestrian slots. Project to width 64;
   a four-head masked attention block returns an ego-context encoding.
3. Maintain deterministic GRU memory `h` (128 values) and Gaussian latent `z`
   (32 values). Reset history at episode boundaries. The initial posterior reads
   the reset observation; online/real-history features use posterior means.

```text
h_next = GRU([z, applied_action, known_weather], h)
prior(z_next) = distribution(prior_net(h_next))
posterior(z_next) = distribution(posterior_net([h_next, attention(next_observation)]))
```

4. Heads decode **absolute normalized state**, presence, object/light classes,
   reward and task termination. This is not a pixel/video model or delta-state MLP.
   Termination is not the same thing as a time-limit truncation.
5. Joint training combines masked posterior reconstruction, 0.5 times prior
   reconstruction, prior reward Huber loss, prior-mean termination BCE and
   0.1 times balanced KL with a one-nat free floor. Applied controls/weather are
   propagated exactly rather than treated as uncertain reconstruction targets.
6. To imagine, branch from a real, fully reconstructed history. Sample the actor,
   run the same action adapter, advance the GRU and sample the **prior**, without
   reading a future CARLA observation. Decode reward/end/next state. Known weather
   and applied control history remain exact. Filter nonfinite/implausible samples.

Candidate 008 uses one imagined decision, **0.1 simulated seconds**, refreshes
imagined replay every 100 SAC updates, and draws 25% synthetic plus 75% real samples
per batch. Gaussian latent variance and physical sanity checks are not a calibrated
epistemic uncertainty estimator. There is no ensemble, online MPC or actor gradient
through the dynamics. SAC uses detached generated features/targets.

In candidates 001–008 the reusable world model is frozen during SAC: collection and
joint refresh counts are zero. The original general training workflow can interleave
collection/refits; that is different from these frozen-model experiments. The world
model still runs at driving time to maintain the actor's latent memory.

## 4. How the warm-start policy works

Here “warm start” means supervised initialization of a **new** actor. It does not
load an earlier SAC actor, critics, Q targets or optimizers.

1. Load the compatible world model and its normalizer. Initialize fresh SAC actor,
   twin critics, target critics and optimizers. Reconstruct training histories.
2. Build demonstration requests from training episodes only. `recorded` accepts
   BasicAgent `autopilot` requests or separate DAgger `expert_actions`. Geometric
   teachers can label any training collector's current observations. These labels
   are counterfactual requests; they do not replace recorded dynamics/rewards.
3. During actor-only warm-up, minimize:

```text
MSE(deterministic_actor_request, teacher_request)
    + 0.01 * MSE(actor_log_std_output, -3)
```

   Critics/world model stay fixed and the SAC update counter stays zero. Candidate
   008 does 50,000 such updates; `policy_bootstrap.jsonl` records their losses.
4. Then run ordinary critic/temperature updates and a demonstration-anchored actor
   objective. For an anchored batch the actor uses:

```text
mean(alpha * log_pi - 2.5 * Q / max(mean(abs(Q)).detach(), 1e-6))
    + behavior_cloning_weight * MSE(deterministic_demo_request, teacher_request)
```

   Candidate 008 uses anchor weight 100, initial alpha 0.001 and 2,000 SAC updates.
   The demonstration batch is separate from real/synthetic critic replay. The
   normalization makes the anchor weight less sensitive to Q magnitude.
5. At evaluation, the deterministic neural actor chooses requests from its input.
   Neither BasicAgent nor the geometric teacher brakes or steers for it. An action
   adapter clips/rate-limits requests and resolves throttle/brake overlap.

Base policy input is 167 values: `h128 + z32 + weather4 + previous_applied3`.
The optional observed-state skip adds 169, producing **336** values in candidate
008: continuous114 + presence12 + class indicators36 + controls2 + light5. The
trailing applied-action contract and latent/weather offsets are preserved. Real/live
skips use the current observation; imagined skips use decoded predictions.

### Teacher versions and sampling

- `recorded`: measured BasicAgent requests or explicit DAgger labels.
- `geometry_v1`: current-state pursuit, curve/weather speed cap, light stopping and
  observed-object clearance. Its steering scale was approximate and superseded.
- `geometry_v2`: measured Tesla wheelbase about 3 m, 70-degree front steering and
  speed-dependent steering curve in km/h. Its speed servo still taught throttle
  0.12 at a zero-speed target because of cruise feed-forward.
- `geometry_v3`: retains calibrated steering and additionally requests zero throttle
  and at least 0.35 brake while the target is <=0.3 m/s; releases when clear.

These functions only see current training observations, not future events/actions.
They assume the Tesla Model3 and do not constitute a guaranteed safe controller.

Default demonstration sampling is half turning/braking examples, half uniform.
`behavior_cloning_traffic_fraction=0.5` in 008 reserves half the batch for near
red/yellow braking states: three quarters moving (>0.3 m/s), one quarter stationary.
The remainder retains manoeuvre/uniform sampling. Missing strata fall back to ordinary
sampling. Training data has 19,208 such red/yellow braking states within 25 m, but
only 3,368 moving states; long waits otherwise dominate.

`behavior_cloning_permute_objects=true` would additionally permute each demonstration's
current observed objects, masks and classes together within the two slot groups.
It preserves context, latent history, previous actions and teacher labels; it does
not change dynamics/Q replay. It is disabled by default and in every trained
checkpoint so far. This was motivated by the 008 audit: reordering equivalent slots
changed braking on 36.8% of sampled held-out states. The audit used no gradients.

### Why red-light running remains possible

The observation supplies route-associated stop-line distance measured from the front
bumper, control validity and light state. The policy must learn when/how strongly
to brake; there is no fixed stand-off guarantee or runtime red-light safeguard.
Reward is +2 per metre of route progress and -20 per red crossing, so 10 m offsets
that penalty before other terms. Raising that saved reward weight would require
compatible new reward-labelled data/model handling; editing a JSON file does not
repair a trained policy or a loaded Python process. The v3 hold and traffic sampling
are training changes, not proof that red-light behavior is fixed.

## 5. Reproducing the work

Use the repository root and matching CARLA client/server build. Recorded runs report
client/server `e6c5fb9ce-dirty`. The checked Python environment is Python 3.10.22,
PyTorch 2.7.1, NumPy 1.26.4 and pytest 8.4.2 on Linux; training used CUDA. Runtime
requirements are in `requirements.txt`; CARLA comes from this checkout's matching
wheel, not an arbitrary PyPI release. Save the original datasets, checkpoint files,
plans and source snapshots when moving the experiment to another machine.

### Re-evaluate the existing latest checkpoint

Use the existing dedicated matching server. If none is running, start it separately
with `bash data/start_server.sh` (`UE4_ROOT` must identify the built engine). Only
one driving/ticking client may own the synchronous world. The evaluation active when
the goal was paused has now finished; no driving job remains live.

```bash
venv/bin/python -m world_model_rl inspect --config runs/town01_prototype_008/config.json
venv/bin/python -m world_model_rl evaluate \
  --config runs/town01_prototype_008/config.json \
  --checkpoint runs/town01_prototype_008/agent.pt \
  --plan runs/town01_prototype_008/development_plan.json \
  --output runs/town01_prototype_008/repeated_development.json --record-traces
```

Choose a new output filename on each repetition. Existing result/trace paths are
refused. Reports include per-weather results, collision episodes, red violations,
`complete` and `prototype_acceptance`. Inspect those values, not just mean return.

For the reserved final protocol, the corresponding command is below. It is supplied
for reproduction; it has **not** been executed and does not imply this candidate
is ready. Do not tune on its outcomes or train on its traces.

```bash
venv/bin/python -m world_model_rl evaluate \
  --config runs/town01_prototype_008/config.json \
  --checkpoint runs/town01_prototype_008/agent.pt \
  --plan runs/town01_prototype_008/final_plan.json \
  --output runs/town01_prototype_008/final_evaluation.json --record-traces
```

Development uses seed offset 2,000,000; final uses 1,000,000 from training seed
20261016, with fixed IDs/weather schedules. Seeds/configs reproduce the procedure,
not a guarantee of bit-identical CARLA percentages: checkpoints do not contain a
complete simulator snapshot, and reset does not restore traffic-light clock state.
Record server state/version and avoid unrelated clients. Use saved JSON/traces to
inspect the exact outcomes already obtained.

### Reproduce fresh SAC candidate 008 from the preserved model/data

This offline stage needs no CARLA connection. Use a new output directory:

```bash
venv/bin/python -m world_model_rl train \
  --config runs/town01_prototype_008/config.json \
  --data runs/town01_training_data_001 \
  --model runs/town01_prototype_001/world_model.pt \
  --output runs/reproduce_008 --policy-updates 2000
```

This includes 50,000 actor warm-up updates before the 2,000 SAC updates. It uses
collection=0, refresh=0, horizon=1, 25% synthetic replay and the fixed validation
suite. It does not reload candidate 008's actor. The new permutation flag defaults
false in current source, preserving 008's selected algorithm.

For the exact historical Python source, run a snapshot as the package in a separate
working directory (rather than accidentally importing the current root package):

```bash
mkdir runs/reproduce_008_code
cp -a runs/town01_prototype_008/source runs/reproduce_008_code/world_model_rl
cd runs/reproduce_008_code
../../venv/bin/python -m world_model_rl train \
  --config ../town01_prototype_008/config.json \
  --data ../town01_training_data_001 \
  --model ../town01_prototype_001/world_model.pt \
  --output ../reproduce_008_snapshot --policy-updates 2000
```

That snapshot contains the Python package; explicit config paths are required.
Use the analogous `evaluation_source/` snapshot to reproduce its evaluation code.
GPU/library scheduling can still prevent bitwise-identical retraining.

### Reproduce the reusable termination-refitted model

Keep the original 104-episode dataset and source model; choose a new checkpoint path:

```bash
venv/bin/python -m world_model_rl fit-termination \
  --config runs/manual/config.json --data runs/manual/data \
  --checkpoint runs/manual/world_model.pt \
  --output runs/reproduced_world_model.pt --updates 2000
```

This is readout refitting, not joint body training. The saved model used by the
experiments remains the authoritative artifact. `experiment.json` in 001 records
its commands and source hash. Standalone `evaluate-model --split validation`
evaluates the whole requested split, which is now twelve episodes in the expanded
dataset; it need not equal the fixed first-ten training gate report. Do not replace
that report with a favorable subset.

### Dataset extension and same-run resume

The 20 new mixed episodes were collected from the 002 policy, using a compatible
isolated copy of the original dataset and this command shape:

```bash
venv/bin/python -m world_model_rl collect \
  --config runs/town01_collection_001/config.json --data NEW_ISOLATED_DATASET \
  --policy-checkpoint runs/town01_prototype_002/agent.pt \
  --expert-probability 0.5 --episodes 20
```

Do not run it against the preserved 124-episode dataset to reproduce its IDs; it
would append more episodes. Use the saved expanded dataset for exact offline inputs.
`runs/town01_collection_001/experiment.json` records collection provenance.

Continuing an existing policy is a different operation:

```bash
venv/bin/python -m world_model_rl train \
  --config runs/town01_prototype_008/config.json --data runs/town01_training_data_001 \
  --resume runs/town01_prototype_008/agent.pt \
  --output runs/town01_prototype_008 --policy-updates 2000
```

This adds updates and overwrites that run's checkpoint; it is not a reproduction of
its original 2,000-update result. Resume restores networks, optimizers, RNG and phase
counters, checks the dataset frontier and does not repeat actor warm-up. Changed
teacher/sampling/augmentation settings require a separate fresh policy experiment.

## 6. Using it in other environments

| Target change | Supported route and what must be checked |
| --- | --- |
| Different routes/seeds in Town01 with the same contract | Evaluate the saved checkpoint with a new valid plan and unused output. Report it as a new test distribution. |
| Another configured weather in the same contract | Plan IDs must follow the config's scheduled weather. Inspect per-weather success, collisions and violations. |
| Another CARLA town | Collect with explicit `--allow-scenario-variation`, then `fit --warm-start` on the combined data and validate each scenario. See COLLECTED_TRAINING.md. Zero-shot transfer is not established. |
| Different ego car, physics, timing or reward | New compatible data/model/run; recalibrate action/steering/stopping. Geometric teachers reject non-Tesla models. Use recorded labels or implement/test a new teacher. |
| Camera/perception input | Implement a frame-synchronized `observation_provider`, preserve the schema/units/masks, disable no-rendering, collect new compatible observations and refit/validate. See DESIGN section 13. |
| Non-CARLA simulator or general Gym task | Reuse the algorithm design, but implement an adapter and usually a new schema, tokenization, action mapping, reward/end definitions, replay checks and gates. This is not a generic plug-in checkpoint. |

For example, prepare a Town02 config outside the new output directory:

```bash
venv/bin/python - <<'PY'
import json
from pathlib import Path
cfg = json.loads(Path('world_model_rl/config.json').read_text())
cfg['environment']['town'] = 'Town02'
cfg['training']['behavior_cloning_updates'] = 10000
cfg['training']['behavior_cloning_weight'] = 10
cfg['training']['behavior_cloning_teacher'] = 'recorded'
cfg['training']['policy_observation_skip'] = True
Path('runs/town02_config.json').write_text(json.dumps(cfg, indent=2) + '\n')
PY
venv/bin/python -m world_model_rl run \
  --config runs/town02_config.json --output runs/town02_new --policy-updates 100000
```

This is a starting experiment, not a performance promise. It uses the general fresh
collection/fitting/interleaved-training workflow; missing coverage or failed model
quality stops it. Plain `fit` initializes a new world model. The integrated
`fit --warm-start CHECKPOINT` mode fine-tunes existing weights with their original
normalizer and optimizer. Explicit scenario variation permits other CARLA towns,
weather and traffic while retaining the ego, physics, observation and reward
contract. It uses all validation episodes and gates each scenario independently.
See [COLLECTED_TRAINING.md](COLLECTED_TRAINING.md) for the consolidated data and
adaptation commands. No transfer performance has yet been demonstrated.

## 7. Verification and outstanding work

```bash
venv/bin/python -m pytest world_model_rl/tests -q
```

Latest full result: **90 passed in 4.88 s on the host**. The viewer socket test needs
local socket permissions. Tests cover interfaces, preservation, causal imagination,
fixed evaluation acceptance, warm-up/anchoring, traffic sampling and scene-preserving
slot permutation. They do not certify safe driving or the untrained augmentation.

Remaining evidence includes a successful full final 50-episode suite, reliable red-light
compliance, collision-ending prediction improvements and actual transfer experiments.
Do not declare the prototype complete from a passing model gate, low cloning loss,
partial evaluation, one successful route, or the number of optimizer updates.
