#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    printf '%s\n' 'Usage: bash world_model_rl/recover_from_scratch.sh RUN_DIR [NEW_EPISODES] [POLICY_UPDATES] [OUTPUT_DIR]' \
        'Appends a fixed batch of new recordings, checks split coverage, then fits fresh model/SAC weights.' \
        'Defaults: 20 new episodes, 100000 SAC updates, a new RUN_DIR/recovery_<timestamp>_<suffix> directory.' \
        'Requires a dedicated CARLA server and a source run without agent.pt. No existing checkpoint weights are reused.'
    exit 0
fi
if (( $# < 1 || $# > 4 )); then
    printf '%s\n' 'Specify RUN_DIR; use --help for arguments.' >&2
    exit 2
fi
RUN_DIR="$1"
NEW_EPISODES="${2:-20}"
POLICY_UPDATES="${3:-100000}"
OUTPUT_DIR="${4:-$RUN_DIR/recovery_$(date +%Y%m%d_%H%M%S)_${RANDOM}}"
CONFIG="$RUN_DIR/config.json"
for budget in "$NEW_EPISODES" "$POLICY_UPDATES"; do
    if [[ ! "$budget" =~ ^[0-9]+$ || ! "$budget" =~ [1-9] ]]; then
        printf '%s\n' 'Episode and policy-update budgets must be positive integers.' >&2
        exit 2
    fi
done
if [[ ! -x venv/bin/python || ! -f "$CONFIG" || ! -f "$RUN_DIR/data/dataset.json" ]]; then
    printf '%s\n' 'Need the repository venv and RUN_DIR/config.json and data/dataset.json.' >&2
    exit 2
fi
if [[ -e "$RUN_DIR/agent.pt" ]]; then
    printf '%s\n' 'This script is for a run blocked before SAC. Refusing to alter a resumable agent dataset.' >&2
    exit 2
fi
if [[ -e "$OUTPUT_DIR" || -L "$OUTPUT_DIR" || -e "$OUTPUT_DIR.log" || -L "$OUTPUT_DIR.log" ]]; then
    printf 'Choose a new output path; refusing to reuse %s or its log.\n' "$OUTPUT_DIR" >&2
    exit 2
fi
mkdir -p -- "$(dirname -- "$OUTPUT_DIR")"
mkdir -- "$OUTPUT_DIR"
cp -- "$CONFIG" "$OUTPUT_DIR/config.json"
CONFIG="$OUTPUT_DIR/config.json"
printf 'New model/policy output: %s\nAppending %s episodes to %s/data\n' "$OUTPUT_DIR" "$NEW_EPISODES" "$RUN_DIR"
recover() {
    venv/bin/python -u -m world_model_rl collect --config "$CONFIG" --data "$RUN_DIR/data" --episodes "$NEW_EPISODES"
    venv/bin/python -u -m world_model_rl validate --config "$CONFIG" --data "$RUN_DIR/data" --for-training
    venv/bin/python -u -m world_model_rl fit --config "$CONFIG" --data "$RUN_DIR/data" --checkpoint "$OUTPUT_DIR/world_model.pt"
    venv/bin/python -u -m world_model_rl train --config "$CONFIG" --data "$RUN_DIR/data" --model "$OUTPUT_DIR/world_model.pt" \
        --output "$OUTPUT_DIR" --policy-updates "$POLICY_UPDATES"
}
recover 2>&1 | tee -- "$OUTPUT_DIR.log"
