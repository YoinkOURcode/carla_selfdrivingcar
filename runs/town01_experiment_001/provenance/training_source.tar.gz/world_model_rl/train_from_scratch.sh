#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    printf '%s\n' 'Usage: bash world_model_rl/train_from_scratch.sh [OUTPUT_DIR] [POLICY_UPDATES] [CONFIG]' \
        'Defaults: a new runs/from_scratch_<timestamp>_<suffix> directory, 100000 SAC updates, world_model_rl/config.json.' \
        'Start a dedicated CARLA server first. Progress is also saved to OUTPUT_DIR.log.'
    exit 0
fi
if (( $# > 3 )); then
    printf '%s\n' 'Too many arguments; use --help.' >&2
    exit 2
fi

OUTPUT_DIR="${1:-runs/from_scratch_$(date +%Y%m%d_%H%M%S)_${RANDOM}}"
POLICY_UPDATES="${2:-100000}"
CONFIG="${3:-world_model_rl/config.json}"
if [[ ! "$POLICY_UPDATES" =~ ^[0-9]+$ || ! "$POLICY_UPDATES" =~ [1-9] ]]; then
    printf '%s\n' 'POLICY_UPDATES must be a positive integer.' >&2
    exit 2
fi
if [[ -e "$OUTPUT_DIR" || -L "$OUTPUT_DIR" || -e "$OUTPUT_DIR.log" || -L "$OUTPUT_DIR.log" ]]; then
    printf 'Choose a new output path; refusing to reuse %s or its log.\n' "$OUTPUT_DIR" >&2
    exit 2
fi
if [[ ! -x venv/bin/python || ! -f "$CONFIG" ]]; then
    printf '%s\n' 'The repository venv/bin/python and configuration file must exist.' >&2
    exit 2
fi
mkdir -p -- "$(dirname -- "$OUTPUT_DIR")"
printf 'Training output: %s\nProgress log: %s.log\n' "$OUTPUT_DIR" "$OUTPUT_DIR"
venv/bin/python -u -m world_model_rl run --config "$CONFIG" --output "$OUTPUT_DIR" \
    --policy-updates "$POLICY_UPDATES" 2>&1 | tee -- "$OUTPUT_DIR.log"
