#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    printf '%s\n' 'Usage: bash world_model_rl/train_collected.sh [OUTPUT_DIR] [POLICY_UPDATES] [MODEL] [CONFIG]' \
        'Defaults: new runs/collected_<timestamp>_<suffix>, 2000 SAC updates,' \
        'runs/world_model_rl/world_model.pt, world_model_rl/configs/collected.json.' \
        'Uses runs/world_model_rl/data and a fresh SAC policy with expert warm-up.' \
        'The default config performs 50000 warm-up updates; no CARLA connection is needed.'
    exit 0
fi
if (( $# > 4 )); then
    printf '%s\n' 'Too many arguments; use --help.' >&2
    exit 2
fi
OUTPUT_DIR="${1:-runs/collected_$(date +%Y%m%d_%H%M%S)_${RANDOM}}"
POLICY_UPDATES="${2:-2000}"
MODEL="${3:-runs/world_model_rl/world_model.pt}"
CONFIG="${4:-world_model_rl/configs/collected.json}"
if [[ ! "$POLICY_UPDATES" =~ ^[0-9]+$ || ! "$POLICY_UPDATES" =~ [1-9] ]]; then
    printf '%s\n' 'POLICY_UPDATES must be a positive integer.' >&2
    exit 2
fi
if [[ -e "$OUTPUT_DIR" || -L "$OUTPUT_DIR" || -e "$OUTPUT_DIR.log" || -L "$OUTPUT_DIR.log" ]]; then
    printf 'Choose a new output path; refusing to reuse %s or its log.\n' "$OUTPUT_DIR" >&2
    exit 2
fi
if [[ ! -x venv/bin/python || ! -f "$CONFIG" || ! -f "$MODEL" || ! -f runs/world_model_rl/data/dataset.json ]]; then
    printf '%s\n' 'Need repository venv, config, world-model checkpoint and runs/world_model_rl/data.' >&2
    exit 2
fi
mkdir -p -- "$(dirname -- "$OUTPUT_DIR")"
printf 'Training output: %s\nProgress log: %s.log\n' "$OUTPUT_DIR" "$OUTPUT_DIR"
venv/bin/python -u -m world_model_rl train --config "$CONFIG" --data runs/world_model_rl/data \
    --model "$MODEL" --output "$OUTPUT_DIR" --policy-updates "$POLICY_UPDATES" 2>&1 | tee -- "$OUTPUT_DIR.log"
