# World model RL command reference

For the exact Town01 artifact paths, warm-start explanation and reproduction/transfer
workflow, see [PROTOTYPE.md](PROTOTYPE.md). No final 50-episode success is claimed.

This reference covers all ten `python -m world_model_rl` subcommands, the live
viewer, and the shell launchers. It describes the interface implemented in
[`__main__.py`](__main__.py), [`runner.py`](runner.py), and
[`viewer.py`](viewer.py). For an introduction, see [README.md](README.md); for
the observation and model contracts, see [DESIGN.md](DESIGN.md).

For the consolidated collected-data workflow, see
[COLLECTED_TRAINING.md](COLLECTED_TRAINING.md). It documents the active dataset/model,
the `train_collected.sh` launcher, imports, and model adaptation after new collection.

## Command index

| Command | Purpose | Running CARLA server required? |
| --- | --- | --- |
| [`inspect`](#inspect) | Print client/server versions and map information. | Yes |
| [`collect`](#collect) | Create or append real driving episodes. | Yes |
| [`merge-data`](#scenario-adaptation-and-dataset-import) | Import unique compatible recordings while preserving source splits. | No |
| [`validate`](#validate) | Check recorded episodes and fitting coverage. | No |
| [`fit`](#fit) | Fit a new world model, or fine-tune with `--warm-start`. | No |
| [`fit-termination`](#fit-termination) | Refit only a world model's task-ending readout. | No |
| [`evaluate-model`](#evaluate-model) | Measure held-out model predictions. | No |
| [`train`](#train) | Train or resume SAC using a fitted world model. | During collection blocks |
| [`evaluate`](#evaluate) | Drive with a trained SAC policy and save metrics. | Yes |
| [`run`](#run) | Collect, fit, and train a complete fresh experiment, or resume it. | During collection |
| [`world_model_rl.viewer`](#live-viewer) | Watch the current vehicle in a local browser. | Yes, with another client advancing the simulation |
| [`train_from_scratch.sh`](#train_from_scratchsh) | Launch a fresh experiment with terminal and file logging. | During collection |
| [`recover_from_scratch.sh`](#recover_from_scratchsh) | Append a fixed data batch to a pre-SAC run, then fit fresh model/policy weights. | During collection |
| [`train_collected.sh`](COLLECTED_TRAINING.md) | Train fresh SAC from the consolidated data and preserved model. | No with default profile |

Additional sections: [setup and shared options](#setup-and-shared-options),
[configuration and budgets](#configuration-and-budgets),
[validation and exit status](#validation-and-exit-status),
[artifacts](#artifacts), and [offline verification](#offline-verification).

## Setup and shared options

### Shared five-hour offline deadline

`fit` and `train` accept `--training-clock PATH`, `--training-seconds SECONDS`
(default 18000) and `--checkpoint-seconds SECONDS` (default 300). Without a
clock path, existing update-budget behavior is unchanged. Use the **same clock
path and interval settings** for fitting and policy training. The first valid
training stage starts the persisted wall-clock deadline; subsequent stages and
resumes cannot reset it. Time spent between commands counts. A clock lock
rejects concurrent training commands sharing the same budget.

The clock covers joint world-model fitting, termination-head fitting, actor
warm-up, and SAC. It is checked between complete optimizer updates and after
imagination. At expiry, save completed state and stop further gradients. A long
inference/encoding operation or optimizer step can delay observing the deadline;
the clock never interrupts an optimizer half way through. Prediction validation
and driving evaluation may run after training stops. A failed imagination gate
still blocks SAC; the deadline does not create a real-only fallback.

Timed policy training requires explicit `collection_episodes=0` and
`refresh_updates=0`, with no pending collection/refresh phase. Collect real data
in fixed batches separately. Timed replay updates never connect to CARLA. The
clock options apply to individual `fit`/`train` stages, not the integrated `run`
command. This is an explicit offline training profile, not a change to package
defaults.

Alongside the latest checkpoint, `checkpoints/` retains immutable candidates at
the interval and at important phase boundaries. The clock JSON lists their
SHA-256 hashes, actual counters, stages and save times. World-model snapshots
include the fitted normalizer, joint optimizer, RNG and any active termination
optimizer; policy snapshots include SAC networks, targets, optimizers, RNG and
partial warm-up counters. Explicit policy resume finishes only the remaining
warm-up updates. Warm-up and SAC logs remain separate. The deadline alone does
not make an untrained or failed-gate checkpoint a valid driving policy.

Command shapes for an existing compatible dataset and a reviewed offline config
are below. They have **not** been launched for `town01_experiment_001`; its host
CARLA/GPU access is still blocked. The large SAC update cap lets the wall-clock
deadline stop the run before that cap. It is not a promised update count.

```bash
venv/bin/python -m world_model_rl fit \
  --config runs/town01_experiment_001/config.json \
  --data runs/town01_experiment_001/data \
  --checkpoint runs/town01_experiment_001/world_model.pt \
  --updates 10000 \
  --training-clock runs/town01_experiment_001/training_clock.json \
  --training-seconds 18000 --checkpoint-seconds 300

venv/bin/python -m world_model_rl train \
  --config runs/town01_experiment_001/config.json \
  --data runs/town01_experiment_001/data \
  --model runs/town01_experiment_001/world_model.pt \
  --output runs/town01_experiment_001 --policy-updates 1000000000 \
  --training-clock runs/town01_experiment_001/training_clock.json \
  --training-seconds 18000 --checkpoint-seconds 300
```

After five hours, use only the reserved development plan to select among saved
neural policy candidates, then evaluate the selected checkpoint using the full
fixed final plan. Record the selection rule and development evidence before
opening final results. No final trajectory may enter fitting, demonstrations,
policy gradients or candidate selection. Runtime access, final experiment
settings and actual full-scope results remain outstanding.

Run the examples from the repository root. They use the existing `venv/bin/python`.
The package uses Python 3.10 or newer; the Python version must also match the CARLA
client wheel. Runtime dependencies are listed in
[`requirements.txt`](requirements.txt): NumPy, PyTorch, and NetworkX. To install
them into an already-created repository environment:

```bash
venv/bin/python -m pip install -r world_model_rl/requirements.txt
```

For commands that connect to CARLA, install this checkout's matching CARLA client
wheel in that same environment and start a dedicated matching server. The repository
server launcher requires `UE4_ROOT` to point to a built Unreal Engine:

```bash
export UE4_ROOT=/absolute/path/to/your/built/UnrealEngine
bash data/start_server.sh
```

Keep the server terminal running. This launcher starts Town01, offscreen rendering,
and RPC port 2000. Collection and policy evaluation own synchronous simulation ticks;
use one driving client per server. The viewer can attach alongside that client.
See [`data/README.md`](../data/README.md) for the server and client setup details.

The main CLI has this form:

```text
venv/bin/python -m world_model_rl COMMAND [OPTIONS]
```

Every main subcommand and the viewer accept these options:

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | The package's `world_model_rl/config.json` | Load JSON configuration, filling omitted fields with the defaults in `config.py`. |
| `-h`, `--help` | — | Print help and exit without executing the command. |

Place subcommand options **after** the subcommand. There is no top-level `--config`
option. Top-level `-h`/`--help` lists the ten commands:

```bash
venv/bin/python -m world_model_rl --help
venv/bin/python -m world_model_rl train --help
venv/bin/python -m world_model_rl.viewer --help
bash world_model_rl/train_from_scratch.sh --help
bash world_model_rl/recover_from_scratch.sh --help
```

The main CLI's help paths do not import CARLA or PyTorch. Viewer help requires NumPy.
Running a main subcommand imports the runtime dependencies, including for offline work.

Relative paths passed to Python commands resolve from the current working directory.
They do not resolve from the configuration file's directory. Both shell launchers
change to the repository root before resolving their arguments. Quote paths containing
spaces. In the usage blocks below, brackets mean an optional argument; do not type them.

Use the experiment's saved configuration when working with existing data or weights:
`--config runs/EXPERIMENT/config.json`. Commands do not automatically discover this
file from `--data`, `--checkpoint`, `--output`, or `--resume`.

## Scenario adaptation and dataset import

All subcommands except `inspect` accept `--allow-scenario-variation`, setting
`training.allow_scenario_variation=true` for that invocation and saved checkpoints.
It permits different towns, weather, traffic, routes and connection settings while
retaining strict ego, physics/timing, action, observation, termination and reward
checks. The default remains strict. Fitting/policy training requires validation
support for every training scenario, uses all validation episodes and gates each
town/weather/traffic/route configuration separately.

`collect` additionally accepts `--town NAME`, `--weather NAME [NAME ...]`,
`--vehicles N`, and `--pedestrians N`, overriding those collection settings. Episodes
record the actual environment configuration. Collection appends data and does not
update model weights.

```bash
venv/bin/python -m world_model_rl merge-data \
  --config world_model_rl/configs/collected.json \
  --data runs/world_model_rl/data --allow-scenario-variation \
  --source runs/another_collection/data
```

`merge-data --source PATH [PATH ...]` imports unique compatible real episodes into
`--data` (default `runs/default/data`). It preflights all sources, rejects evaluation
traces and cross-split town/seed reuse, preserves source files and split assignments,
reassigns conflicting IDs, and records source provenance in `imported_from` sidecar
metadata. Recording-content checksums deduplicate independently of NPZ compression
or numeric episode IDs. `DATA/imports.jsonl` records counts. Repeated imports add
no duplicate episodes. See [COLLECTED_TRAINING.md](COLLECTED_TRAINING.md) for adaptation
and retraining after import.

## `inspect`

Connect to CARLA and print a JSON summary of the current server. This is a useful
connection check before collection. It queries the current map without loading the
configured town or advancing simulation ticks.

```text
venv/bin/python -m world_model_rl inspect [--config PATH]
```

Only the [shared options](#setup-and-shared-options) apply.

```bash
venv/bin/python -m world_model_rl inspect --config world_model_rl/config.json
```

**Output:** stdout JSON containing `client`, `server`, `map`, `available_maps`,
and `spawn_points`. It writes no dataset or checkpoint. Compare the printed versions;
the driving environment rejects differing client/server versions.

## `collect`

Record complete real episodes using the route-following expert controller. Create a
dataset if necessary, or append episodes with new IDs to a compatible existing dataset.

```text
venv/bin/python -m world_model_rl collect [--config PATH] [--data DIR]
    [--episodes N] [--controller {mixed,autopilot,noisy}]
    [--policy-checkpoint FILE] [--expert-probability P]
```

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | Packaged config | Configuration for this dataset and CARLA session. |
| `--data DIR` | `runs/default/data` | Dataset directory to create or append to. |
| `--episodes N` | `training.bootstrap_episodes` = `20` | Number of additional episodes to record; must be positive. |
| `--controller MODE` | `mixed` | `autopilot`: BasicAgent expert; `noisy`: expert with action noise; `mixed`: expert on even episode IDs and noisy expert on odd IDs. |
| `--policy-checkpoint FILE` | None | Agent for expert-labelled mixed policy collection. Replaces controller mode; deterministic policy/expert execution is selected independently per decision. |
| `--expert-probability P` | `0.5` | Expert execution probability for labelled policy collection, in `[0,1]`. Every decision still receives a separate expert action label. |

Here `autopilot` names the package's BasicAgent controller. It is not a request to
enable Traffic Manager autopilot on the ego vehicle. Mixed collection uses absolute
dataset episode IDs, so alternation continues when appending.

```bash
venv/bin/python -m world_model_rl collect \
  --config world_model_rl/config.json --data runs/manual/data \
  --episodes 20 --controller mixed
```

**Requires:** a dedicated running CARLA server. Collection can load the configured
town and applies synchronous settings for the session. Weather, route selection,
traffic, pedestrians, and step limits come from the configuration.

**Output:** `dataset.json`, `episode_XXXXXX.npz`, matching JSON metadata,
`splits.json`, and appended `collection.jsonl` summaries under `--data`. Existing
episodes are preserved. Configuration/schema/reward/split-seed mismatches and an
interrupted episode sidecar cause failure rather than reuse of incompatible data.

## `validate`

Check stored episodes without connecting to CARLA or fitting a model. Validation
checks shapes, numeric values, actions, timing, rewards, ending flags, schema,
metadata, and split assignments. It also reports whether training and the fixed
validation suite contain enough event support to begin fitting.

```text
venv/bin/python -m world_model_rl validate [--config PATH] [--data DIR]
    [--for-training]
```

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | Packaged config | Must be compatible with the dataset. |
| `--data DIR` | `runs/default/data` | Existing recorded dataset. |
| `--for-training` | Off | Exit with code `2` if the reported fitting coverage is insufficient. |

```bash
venv/bin/python -m world_model_rl validate \
  --config world_model_rl/config.json --data runs/manual/data --for-training
```

**Output:** stdout JSON with episode/transition totals, split counts,
`event_decision_counts`, and `fitting_coverage`. The command does not save a report
file itself. To retain the JSON, redirect stdout to a file in an existing directory:

```bash
venv/bin/python -m world_model_rl validate \
  --config world_model_rl/config.json --data runs/manual/data --for-training \
  > runs/manual/coverage.json
```

Without `--for-training`, insufficient event coverage is reported as
`fitting_coverage.ready=false` but does not by itself cause a nonzero exit status.
Malformed or incompatible recordings still fail. This command checks data support;
it does not measure a model's prediction quality.

## `fit`

By default, fit a randomly initialized attention/RSSM world model, a training-only
normalizer and a new optimizer. `--warm-start FILE` instead fine-tunes an existing
world-model checkpoint while retaining its normalizer and optimizer. Joint fitting
is followed by termination-readout fitting and held-out model evaluation. Model
and termination counters continue from the source; no SAC weights are imported.

```text
venv/bin/python -m world_model_rl fit [--config PATH] [--data DIR]
    --checkpoint FILE [--updates N] [--warm-start FILE] [--allow-scenario-variation]
```

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | Packaged config | Dataset-compatible configuration and fitting settings. |
| `--data DIR` | `runs/default/data` | Existing training/validation recordings. |
| `--checkpoint FILE` | **Required** | New output world-model checkpoint file, usually ending in `.pt`. |
| `--updates N` | `training.pretrain_updates` = `10000` | Positive number of joint model optimizer updates. |
| `--warm-start FILE` | Unset | Existing world-model checkpoint to fine-tune; retain its normalizer/optimizer and save to the new `--checkpoint` path. |

```bash
venv/bin/python -m world_model_rl fit \
  --config world_model_rl/config.json --data runs/manual/data \
  --checkpoint runs/manual/world_model.pt --updates 10000
```

The termination stage adds `training.termination_fit_updates` updates (`2000` by
default); these are additional to `--updates`. Only the training split contributes
to normalization or gradients. The validation suite is the first up to
`training.validation_episodes` validation episodes, preserving split assignments.

**Output:** for `--checkpoint runs/manual/world_model.pt`:

| Artifact | Contents |
| --- | --- |
| `runs/manual/world_model.coverage.json` | Pre-fit training/validation support report, also written when coverage blocks fitting. |
| `runs/manual/world_model.pt` | World-model weights, normalizer, optimizer, configuration, counters, validation, and fitting metadata. |
| `runs/manual/world_model.validation.json` | Held-out prediction and termination metrics. |
| `runs/manual/world_model_training.jsonl` | Appended joint fitting progress and timings. |
| `runs/manual/termination_training.jsonl` | Appended termination fitting progress and timings. |

The report names **replace** the checkpoint's suffix: `model.pt` produces
`model.coverage.json` and `model.validation.json`.

An existing checkpoint is refused. Missing fitting coverage exits with code `2`
before device/model allocation or gradient updates. Once fitting completes, a
failed prediction gate is printed and the model/report are still saved; `fit`
does not fail solely because that later gate fails. `train` enforces the gate
before policy updates or further driving collection.

## `fit-termination`

Refit only the task-ending readout of an existing fitted world model. The dynamics,
encoder, reward predictions, and normalizer stay fixed. Class-balanced training
uses full real histories and a correction based on training event prevalence.

```text
venv/bin/python -m world_model_rl fit-termination [--config PATH] [--data DIR]
    --checkpoint FILE --output FILE [--updates N]
```

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | Packaged config | Must match the source checkpoint and dataset. |
| `--data DIR` | `runs/default/data` | Existing real training and validation episodes. |
| `--checkpoint FILE` | **Required** | Input checkpoint of kind `world_model`; an SAC agent is rejected. |
| `--output FILE` | **Required** | New output world-model checkpoint file. |
| `--updates N` | `training.termination_fit_updates` = `2000` | Positive number of termination-readout updates. |

```bash
venv/bin/python -m world_model_rl fit-termination \
  --config world_model_rl/config.json --data runs/manual/data \
  --checkpoint runs/manual/world_model.pt \
  --output runs/manual/world_model_termination.pt --updates 2000
```

**Requires:** nonempty training and validation splits, both task-ending and
nonterminal training transitions, and `training.batch_size >= 2`. It does not run
the separate `fit` coverage preflight. Missing validation endings can still make
its post-fit prediction gate fail.

**Output:** the new world-model checkpoint, `OUTPUT_STEM.validation.json`, and
`termination_training.jsonl` beside the output checkpoint. Existing output files
are refused; the input checkpoint is preserved. The model version and termination
update counter increase; the joint model update counter is retained. No SAC state
is imported. As with `fit`, a failed post-fit prediction gate is reported but does
not by itself fail the command.

Use the resulting checkpoint with `train --model` to start a fresh SAC policy.
Additional head updates cannot supply missing held-out labels, and repeated
head-only fitting may not resolve a training/held-out generalization gap.

## `evaluate-model`

Measure the world model against recorded held-out episodes. This is offline
prediction evaluation; it does not drive a vehicle or update weights.

```text
venv/bin/python -m world_model_rl evaluate-model [--config PATH] [--data DIR]
    --checkpoint FILE [--split {validation,test}] [--output FILE]
```

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | Packaged config | Must match the checkpoint and dataset. |
| `--data DIR` | `runs/default/data` | Existing dataset containing the selected split. |
| `--checkpoint FILE` | **Required** | A world-model or agent checkpoint; agent checkpoints contain the latest refreshed model. |
| `--split SPLIT` | `test` | Select `validation` or `test`; there is no training-split option. |
| `--output FILE` | `runs/default/test_model.json` | Destination report file; an existing report is replaced. |

```bash
venv/bin/python -m world_model_rl evaluate-model \
  --config runs/manual/config.json --data runs/manual/data \
  --checkpoint runs/manual/agent.pt --split test \
  --output runs/manual/test_model.json
```

**Output:** the same report is printed as JSON and written to `--output`, creating
parent directories. It includes prediction errors by horizon, reward errors,
object/light metrics, event support, termination precision/recall/Brier score,
per-episode diagnostics, and bounded false-alarm groups. If the split is empty,
the report has `available=false` and a reason.

This command evaluates **all** episodes in the selected split. It does not apply
the capped fixed validation suite used by fitting and SAC training, and it does
not enforce a pass/fail gate through its exit status. `--output` remains
`runs/default/test_model.json` even when `--split validation` is selected, unless
you override it. Keep the test split for final assessment rather than fitting or
choosing changes to pass validation.

## `train`

Train SAC from a fitted world model, or recover the same interrupted SAC session
from an agent checkpoint. Supply exactly one of `--model FILE` or `--resume FILE`.
These are checked at runtime even though argparse lists them as optional.

```text
venv/bin/python -m world_model_rl train [--config PATH] [--data DIR]
    (--model FILE | --resume FILE) [--output DIR]
    [--policy-updates N | --episodes N]
```

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | Packaged config | Compatible dataset/model settings; resume also checks training settings. |
| `--data DIR` | `runs/default/data` | Existing real dataset; new policy collection episodes are appended here. |
| `--model FILE` | Unset | Input checkpoint of kind `world_model`; initialize fresh SAC actor, critics, and optimizers. |
| `--resume FILE` | Unset | Input checkpoint of kind `agent`; restore the same training session. Requires a file path. |
| `--output DIR` | `runs/default` | Directory for `agent.pt`, saved config, reports, and progress logs. |
| `--policy-updates N` | `training.policy_updates` = `100000` when neither budget flag is supplied | Additional SAC optimizer updates for this invocation; positive and mutually exclusive with `--episodes`. |
| `--episodes N` | Unset | Additional real SAC collection episodes, across dataset splits; positive and mutually exclusive with `--policy-updates`. |

Start a new SAC policy from the fitted world model:

```bash
venv/bin/python -m world_model_rl train \
  --config world_model_rl/config.json --data runs/manual/data \
  --model runs/manual/world_model.pt --output runs/manual \
  --policy-updates 100000
```

Resume that session, adding 10,000 optimizer updates:

```bash
venv/bin/python -m world_model_rl train \
  --config runs/manual/config.json --data runs/manual/data \
  --resume runs/manual/agent.pt --output runs/manual --policy-updates 10000
```

Alternatively, finish after four additional real SAC collection episodes:

```bash
venv/bin/python -m world_model_rl train \
  --config runs/manual/config.json --data runs/manual/data \
  --resume runs/manual/agent.pt --output runs/manual --episodes 4
```

**Behavior:** encode real training replay, evaluate the fixed validation suite,
and require the imagination gate before policy updates or collection. The default
schedule performs 10,000-update policy blocks, then collects two SAC episodes,
refreshes the model with 200 joint updates plus termination fitting, rebuilds
replay, and validates again. An update budget can finish before another collection
block; an episode budget includes the intervening optimizer blocks and model
refreshes. Replay optimizer blocks themselves do not connect to CARLA.

With defaults, SAC batches use 75% real and 25% imagined transitions. Imagination
is refreshed every 100 optimizer updates and spans one decision (`0.1` simulated
seconds). The normalizer stays fixed. Failed validation blocks further SAC with
exit code `2`; there is no real-only fallback.

Optional actor warm-up and demonstration anchoring are selected in configuration,
not new CLI flags. Warm-up uses training-split labels only, initializes a new actor,
leaves critics fixed and does not count toward `--policy-updates`. `recorded` accepts
autopilot/DAgger labels; geometric teachers can label any training collector's current
states. A geometric teacher is never called during evaluation. See the configuration
table below and PROTOTYPE.md for the exact loss and candidate 008 settings.

**Resume requirements:** restore networks, optimizers, RNG state, model version,
and phase counters. Environment/reward/model configuration must match; training
settings must match apart from device and update budgets. The dataset's next
episode ID must match the checkpoint frontier. Do not append episodes separately
to a dataset that belongs to a resumable agent. An unfinished, unsaved simulator
episode restarts from its seed; partial simulator state is not restored.

**Output:** `agent.pt`, `config.json`, `validation.json`, `training.jsonl`,
and fitting/termination logs when refreshes occur. The dataset remains at
`--data`; setting `--output` does **not** change `--data`. A fresh `train` refuses
an output containing `agent.pt`; it can use the directory containing the initial
world model. Resume updates the agent checkpoint at `--output/agent.pt`.
Checkpoints are saved every `training.checkpoint_updates` updates (`1000` by
default) and at phase boundaries. Validation failures save `validation.json`;
the initial gate can fail before a new `agent.pt` or output config is written.

## `evaluate`

Drive using the deterministic SAC actor from an agent checkpoint. No fitting or
policy updates occur, and evaluation episodes are not appended to a dataset.

```text
venv/bin/python -m world_model_rl evaluate [--config PATH] --checkpoint FILE
    [--episodes N] [--output FILE] [--seed-offset N] [--plan FILE] [--record-traces]
```

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | Packaged config | Must match the agent checkpoint's environment/reward/model settings. |
| `--checkpoint FILE` | **Required** | Agent checkpoint containing SAC state; a world-model-only checkpoint is rejected. |
| `--episodes N` | `10` | Positive number of live evaluation episodes. |
| `--output FILE` | `runs/default/evaluation.json` | Destination JSON report; an existing report is refused. |
| `--seed-offset N` | `100000` | Integer offset added to `training.seed`; episode `i` uses `training.seed + seed_offset + i`. |
| `--plan FILE` | None | Fixed JSON scenarios (`format: 1`, `town`, and `scenarios` with episode ID, seed, weather). Overrides episode count and scenario seeds. |
| `--record-traces` | Off | Save diagnostic NPZ/JSON trajectories to a sibling `OUTPUT_STEM_traces` directory; existing paths are refused. Traces are explicitly excluded from training. |

```bash
venv/bin/python -m world_model_rl evaluate \
  --config runs/manual/config.json --checkpoint runs/manual/agent.pt \
  --episodes 10 --seed-offset 100000 --output runs/manual/evaluation.json
```

**Requires:** a dedicated running CARLA server and the matching client.

**Output:** a JSON file with `episodes`, `seed_offset`, `mean_return`,
`success_rate`, and `mean_route_completion`. Episode summaries include route completion,
ending reason, event counts, collision rate, lane/heading errors, and comfort
metrics. Episode progress is printed to the terminal; the aggregate JSON is
written to the file rather than printed. Parent directories are created. Reports are
saved after each episode, include `complete`, `per_weather`, `collision_episode_rate`,
and `prototype_acceptance`, and cannot pass acceptance while incomplete. The prototype
criterion requires 50 episodes balanced ten per configured weather across five weathers,
at least 80% successes, and at most 10% collision episodes. A development suite is not a
substitute for this final evaluation. Freeze the plan before training and keep its seeds
and trajectories out of model/policy fitting.
Reports additionally contain `red_light_violations`, `red_light_episodes` and
`red_light_episode_rate`, overall and per weather. These supplement the stated
success/collision acceptance rule; success alone does not establish traffic compliance.
Recorded evaluation traces carry `split: evaluation` and never-train provenance;
dataset save/load rejects them even if wrapped in a compatible dataset manifest.

## `run`

Run the full pipeline in a fresh experiment directory, or resume an existing
experiment's agent. This command owns its data/checkpoint paths under `--output`.

```text
venv/bin/python -m world_model_rl run [--config PATH] [--output DIR]
    [--resume] [--policy-updates N | --episodes N]
```

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | Packaged config | Bootstrap, model, SAC, and environment settings. Pass the saved config explicitly for resume. |
| `--output DIR` | `runs/default` | Fresh experiment directory, or the experiment to resume. |
| `--resume` | Off | Resume `OUTPUT/agent.pt` with `OUTPUT/data`. This is a boolean flag, with no path argument. |
| `--policy-updates N` | `training.policy_updates` = `100000` when neither budget flag is supplied | Positive additional SAC optimizer-update budget. |
| `--episodes N` | Unset | Positive additional SAC collection-episode budget; mutually exclusive with `--policy-updates`. |

Start a fresh experiment:

```bash
venv/bin/python -m world_model_rl run \
  --config world_model_rl/config.json --output runs/experiment \
  --policy-updates 100000
```

The fresh sequence is:

1. Require a new or empty output directory and save `config.json`.
2. Collect `training.bootstrap_episodes` new episodes into `OUTPUT/data`.
3. Check coverage, initialize a new model/normalizer/optimizer, and fit
   `OUTPUT/world_model.pt`.
4. Validate and start fresh SAC weights, writing `OUTPUT/agent.pt` as training proceeds.

At least ten bootstrap episodes and a positive `training.pretrain_updates` budget
are required. `--episodes` changes the subsequent SAC collection budget; it does
not change bootstrap collection. There is no `run --data` or `run --model` option.

Resume the same interrupted experiment:

```bash
venv/bin/python -m world_model_rl run \
  --config runs/experiment/config.json --output runs/experiment \
  --resume --policy-updates 10000
```

Resume requires `OUTPUT/agent.pt` and applies the [train resume checks](#train).
It does not resume partially completed bootstrap collection or initial fitting.
If no agent exists, inspect the recorded artifacts and use the individual stages
or the recovery launcher as appropriate. For an external dataset, such as one used
by the recovery launcher, use `train --data ... --resume FILE`.

## Live viewer

The viewer is a separate Python module, not a main-CLI subcommand:

```text
venv/bin/python -m world_model_rl.viewer [--config PATH] [--port N]
```

| Option | Default | Meaning |
| --- | --- | --- |
| `--config PATH` | Packaged config | Uses `environment.host` and `environment.port` to locate CARLA. |
| `--port N` | `8080` | Local HTTP port, from `1` through `65535`; independent of CARLA's RPC port. |
| `-h`, `--help` | — | Print help and exit. |

In another terminal while collection or training is running:

```bash
venv/bin/python -m world_model_rl.viewer \
  --config runs/experiment/config.json --port 8080
```

Open <http://127.0.0.1:8080>. The HTTP server binds to loopback only. It attaches
a 960 × 540 chase camera to the vehicle with role `world_model_rl`, follows new
vehicles across episodes, and waits during offline fitting or replay updates.
It also works with the offscreen server. The viewer does not tick, change world
settings, or control the vehicle; extra rendering uses GPU time.

Use a different `--port` if the local HTTP port is occupied. The CARLA connection
uses a fixed three-second timeout in the viewer. Ctrl+C stops the viewer and
cleans up its camera. It produces no saved video; recorded NPZ episodes contain
no camera footage for playback. Its local HTTP endpoints are `/` (page),
`/status` (JSON), and `/frame.png` (latest frame, or HTTP 204 while none is available).

The dashboard includes speed (km/h and m/s), the current observation's object slots
(class, actor ID, position and confidence), and accumulated reward for the current
episode. Rewards reset at episode start. The observation source is displayed explicitly:
the default objects are CARLA ground truth with geometric visibility filtering.
SAC/DAgger episodes also show encoder attention weights by input and by head;
expert-only bootstrap episodes have no model attention. This is structured token
attention, not a camera heatmap or a causal explanation of policy actions.

Additional panels show actual versus cautious target speed, route completion and distance
remaining along the route, and steering/throttle/brake values applied after action limits.
The reward table shows signed components for the last decision and their episode totals;
all accumulated reward values reset at the next episode. Steering uses CARLA's signed
`[-1, 1]` scale (left to right); throttle and brake are displayed as percentages.

Restart both driving and viewer processes after upgrading. They share an atomic
temporary snapshot on the same machine/user, keyed by `environment.host` and
`environment.port`; use matching endpoints. `/status` includes a `telemetry` object
or `null` when unavailable. Data older than five seconds is flagged stale. The
state's simulation frame is displayed because camera frames are independently
sampled. Telemetry failures warn once in the driving process and do not stop driving.

## `train_from_scratch.sh`

Launch `run` with a fresh directory, unbuffered Python output, and a sibling log.

```text
bash world_model_rl/train_from_scratch.sh [OUTPUT_DIR] [POLICY_UPDATES] [CONFIG]
```

| Positional argument | Default | Meaning |
| --- | --- | --- |
| `OUTPUT_DIR` | `runs/from_scratch_<YYYYMMDD_HHMMSS>_<random>` | New experiment directory. |
| `POLICY_UPDATES` | `100000` | Positive SAC update budget, passed explicitly as `--policy-updates`. |
| `CONFIG` | `world_model_rl/config.json` | Existing JSON configuration file. |

```bash
bash world_model_rl/train_from_scratch.sh
bash world_model_rl/train_from_scratch.sh runs/experiment5 50000 my_config.json
```

Arguments are positional: to provide `CONFIG`, provide the first two arguments
as well. `-h` or `--help` as the first argument prints help and exits.

The script changes to the repository root, checks the repository interpreter and
configuration, and refuses any existing output directory, file, symlink, or
`OUTPUT_DIR.log`. Unlike direct fresh `run`, it also refuses an empty existing
directory. It then executes the equivalent of:

```text
venv/bin/python -u -m world_model_rl run --config CONFIG --output OUTPUT_DIR
    --policy-updates POLICY_UPDATES
```

**Output:** the normal `run` artifacts plus combined stdout/stderr streamed to
the terminal and `OUTPUT_DIR.log`. The script has no resume mode and does not
start CARLA. Its explicit update budget overrides `training.policy_updates` in
the config. Argument/preflight failures exit with code `2`; pipeline failures
remain nonzero through `tee` (normally the Python command's failure status).

## `recover_from_scratch.sh`

Recover an experiment blocked before SAC by recording a fixed additional batch,
checking coverage, and fitting fresh world-model and policy weights. Existing
recordings are retained and extended; existing checkpoint weights are not loaded.

```text
bash world_model_rl/recover_from_scratch.sh RUN_DIR [NEW_EPISODES]
    [POLICY_UPDATES] [OUTPUT_DIR]
```

| Positional argument | Default | Meaning |
| --- | --- | --- |
| `RUN_DIR` | **Required** | Source run containing `config.json` and `data/dataset.json`, without `agent.pt`. |
| `NEW_EPISODES` | `20` | Positive fixed number of additional mixed-controller episodes to record. |
| `POLICY_UPDATES` | `100000` | Positive SAC update budget after successful fitting/validation. |
| `OUTPUT_DIR` | `RUN_DIR/recovery_<YYYYMMDD_HHMMSS>_<random>` | New directory for the fresh model, policy, and copied config. |

```bash
bash world_model_rl/recover_from_scratch.sh runs/experiment4 20 100000
bash world_model_rl/recover_from_scratch.sh \
  runs/experiment4 20 50000 runs/recovered_experiment4
```

`-h` or `--help` as the first argument prints help and exits. All paths resolve
from the repository root. The launcher requires the repository interpreter, refuses
a source with `agent.pt`, and refuses an existing output path or sibling log.

The sequence is:

1. Create `OUTPUT_DIR` and copy `RUN_DIR/config.json` there.
2. Run `collect` once, appending exactly `NEW_EPISODES` if collection completes.
3. Run `validate --for-training`; stop on inadequate coverage.
4. Run fresh `fit`, writing `OUTPUT_DIR/world_model.pt`.
5. Run `train --model`, writing fresh SAC state under `OUTPUT_DIR` if its gate passes.

It does not loop until favorable validation outcomes appear. Data are appended to
**`RUN_DIR/data`**, not `OUTPUT_DIR/data`; old episode/split assignments are preserved.
The configured validation cap can mean that newly appended validation episodes do
not join an already-full fitting/training suite. Neither more head fitting nor
appending data guarantees a passing gate.

**Output:** fresh checkpoints/reports/logs under `OUTPUT_DIR`, the extended source
dataset, and terminal/file progress in `OUTPUT_DIR.log`. It stops at a failed
stage and retains completed work. Argument/preflight failures exit with code `2`;
stage failures propagate through the pipeline. A running dedicated CARLA server
is required for collection; the script does not launch it.

To resume an agent produced by this script, pass its external dataset explicitly:

```bash
venv/bin/python -m world_model_rl train \
  --config runs/recovered_experiment4/config.json --data runs/experiment4/data \
  --resume runs/recovered_experiment4/agent.pt \
  --output runs/recovered_experiment4 --policy-updates 10000
```

## Configuration and budgets

Host, town, weather, model sizes, device, and most training settings are JSON
configuration fields rather than CLI flags. Copy
[`config.json`](config.json) to a new path for a new experiment, edit it, and
select it using `--config PATH`. Only the `environment`, `reward`, `model`, and
`training` sections and their declared fields are accepted; see
[`config.py`](config.py) for all fields and validation rules.

The settings most directly related to command behavior are:

| Field | Default | Effect |
| --- | --- | --- |
| `environment.host` / `environment.port` | `127.0.0.1` / `2000` | CARLA connection. Viewer `--port` controls a separate HTTP listener. |
| `environment.tm_port` | `8000` | Traffic Manager port for driving sessions. |
| `environment.timeout` | `30.0` seconds | Driving/inspect client timeout; viewer uses its own timeout. |
| `environment.town` | `Town01` | Map loaded by driving sessions if needed. |
| `environment.fixed_delta_seconds` / `action_repeat` | `0.05` / `2` | One decision spans `0.1` simulated seconds. |
| `environment.max_steps` | `1800` | Maximum decisions per episode before time-limit truncation. |
| `environment.no_rendering_mode` | `false` | Disable viewport drawing for structured ground-truth runs; camera providers require rendering. Prior settings are restored on close. |
| `training.seed` | `20261016` | Seeds collection, training, and fixed dataset split assignments. |
| `training.device` | `auto` | CUDA when available, otherwise CPU; `cpu` forces CPU and `cuda` requires CUDA. |
| `training.bootstrap_episodes` | `20` | Default standalone collection count and fresh `run` bootstrap count. |
| `training.pretrain_updates` | `10000` | Default joint updates in `fit` and fresh `run`. |
| `training.termination_fit_updates` | `2000` | Readout updates after fitting/refreshes and default for `fit-termination`. |
| `training.policy_updates` | `100000` | Default additional SAC update budget for direct `train`/`run`. |
| `training.policy_block_updates` | `10000` | SAC updates between collection phases. |
| `training.collection_episodes` | `2` | SAC episodes collected per collection phase; must be positive for an episode budget. |
| `training.refresh_updates` | `200` | Joint model updates after a policy collection phase. |
| `training.minimum_real_steps` | `500` | Minimum real training transitions for fitting/SAC. |
| `training.replay_steps` | `100000` | Recent real training replay budget, loaded as whole episodes. |
| `training.synthetic_fraction` | `0.25` | Fraction of SAC samples from imagined replay. |
| `training.imagination_horizon` | `1` | Imagined decisions per branch; supported values are `1`, `3`, or `5`. |
| `training.imagination_refresh_updates` | `100` | SAC update interval between imagined replay generations. |
| `training.validation_episodes` | `10` | Maximum whole episodes in the fixed fitting/SAC validation suite. |
| `training.checkpoint_updates` | `1000` | Periodic SAC checkpoint interval; phase boundaries also save checkpoints. |
| `training.behavior_cloning_updates` | `0` | Actor-only supervised warm-up updates before fresh SAC training; not repeated by resume. |
| `training.behavior_cloning_weight` | `0.0` | Continued demonstration penalty in SAC actor updates; zero disables anchoring. |
| `training.behavior_cloning_teacher` | `recorded` | `recorded`, `geometry_v1`, `geometry_v2` or `geometry_v3`; geometric teachers require the Tesla Model3 ego. |
| `training.policy_observation_skip` | `false` | Add 169 current/predicted structured values beside latent features; 336 total with the default model. |
| `training.behavior_cloning_traffic_fraction` | `0.0` | Demonstration fraction reserved for near red/yellow stopping: 3/4 moving, 1/4 waiting; remainder keeps manoeuvre/uniform balance. |
| `training.behavior_cloning_permute_objects` | `false` | Training-only demonstration object geometry/mask/class permutation; requires the skip. Implemented but no trained checkpoint uses it yet. |

`--episodes`, `--updates`, and `--policy-updates` accept positive integers when
present. `--updates` is a model-fitting budget; `--policy-updates` counts SAC
optimizer updates. `train`/`run --episodes` counts additional live SAC episodes
and overrides the configured update-budget stopping rule. It excludes fresh-run
bootstrap episodes. Resume budgets are additional work, not lifetime totals.
`evaluate --episodes` defaults to ten independently of the training configuration.

Datasets enforce compatible environment/reward/model configuration and the original
split seed. Checkpoints enforce environment/reward/model compatibility. Same-run
SAC resume additionally checks training settings apart from device and budgets.
Use the saved configuration rather than changing dynamics or model dimensions
under existing artifacts. A new observation contract requires compatible fresh data
and model weights.

## Validation and exit status

Two different checks govern training:

1. **Fitting coverage:** enough real training transitions, at least one training
   task ending and one nonterminal transition, plus configured validation support.
   Defaults require at least one validation ending and twenty nonterminal
   validation transitions. `validate --for-training` exposes this check;
   `fit` performs it before gradients.
2. **Prediction gate:** held-out normalized prediction, reward, speed, lane,
   heading, and termination metrics must pass before SAC updates or additional
   SAC collection. The same fixed suite is retained across refreshes and resume.

Time-limit and stuck endings are truncations and count as nonterminal labels.
True task terminations, including success or collision, supply positive labels.
Whole episodes receive fixed seeded 8/1/1 train/validation/test assignments per
complete block of ten IDs; commands do not move episodes to improve coverage.

Default prediction-gate thresholds are:

| `training` field | Requirement |
| --- | --- |
| `gate_normalized_rmse` | Normalized prediction RMSE ≤ `0.75`. |
| `gate_reward_mae` | Reward-sum MAE ≤ `10.0`. |
| `gate_speed_mae` | Forward-speed MAE ≤ `2.0` m/s. |
| `gate_lane_mae` | Lane-offset MAE ≤ `0.5` m. |
| `gate_heading_mae` | Heading MAE ≤ `0.2` radians. |
| `gate_terminal_brier` | Termination Brier score ≤ `0.2`. |
| `gate_terminal_recall` | Termination recall ≥ `0.5`. |
| `gate_terminal_precision` | Termination precision ≥ `0.5`. |
| `gate_min_terminal_positive` | At least `1` positive validation label. |
| `gate_min_terminal_negative` | At least `20` negative validation labels. |

Prediction checks use the configured imagination horizon. Missing held-out episodes,
insufficient sequence lengths, nonfinite metrics, or insufficient ending support
also block SAC. Twenty collected episodes do not guarantee that the gate passes.
Inspect `termination.endings`, `termination.by_episode`, and
`termination.false_positive_groups` to understand failures. False-alarm groups
describe the first twenty contiguous groups in time order; total metrics still
include every transition. These contexts do not establish the cause of an error.

| Situation | Exit behavior |
| --- | --- |
| Successful command, or help | `0`. |
| Missing/unknown CLI arguments, unsupported command, invalid explicit budget, or invalid viewer port | Argparse exits `2`. |
| `validate --for-training` or `fit` fails fitting coverage | `2`, with an explanation; fitting has not begun. |
| `train` or `run` fails the prediction gate | `2`; inspect `OUTPUT/validation.json`. |
| `fit` or `fit-termination` completes but prediction gate fails | Still `0`; the saved model/report can be inspected, but SAC will enforce the gate. |
| `evaluate-model` reports poor predictions or an empty split | Still `0` if evaluation/report writing completes; inspect the JSON. |
| Other runtime failures, such as file conflicts, incompatible configs, unavailable requested CUDA, connection failures, or invalid recordings | Nonzero, generally a Python traceback; these are not all normalized to `2`. |

## Artifacts

For a complete `run --output runs/experiment`, the principal artifacts are:

| Path | Meaning |
| --- | --- |
| `config.json` | Experiment configuration, written before fresh collection. |
| `data/dataset.json` | Dataset schema, configuration, reward version, and split rule. |
| `data/episode_XXXXXX.npz` / `.json` | Numeric trajectory and its provenance/summary metadata. |
| `data/splits.json` | Whole-episode split membership. |
| `data/collection.jsonl` | Expert bootstrap/standalone collection summaries. SAC collection is logged in `training.jsonl`. |
| `world_model.pt` | Initial fitted world model; SAC refreshes are stored in `agent.pt`. |
| `world_model.coverage.json` | Pre-fit label and transition support. |
| `world_model.validation.json` | Initial fitted model evaluation. |
| `agent.pt` | Latest SAC state, refreshed world model, optimizer/RNG state, and resume counters. |
| `validation.json` | Most recent SAC validation report, including one that blocks training. |
| `training.jsonl` | SAC progress, collection summaries, model refreshes, and timings. |
| `world_model_training.jsonl` | Joint initial fitting/refresh progress. |
| `termination_training.jsonl` | Termination fitting/refresh progress. |

The launchers additionally write `OUTPUT_DIR.log` **beside** the output directory.
Direct Python commands do not create that terminal transcript automatically.
`evaluate-model` and `evaluate` write their separately selected JSON output files.
Most diagnostic JSON reports replace existing files; evaluation refuses an existing
result/trace path, and fitting refuses existing checkpoint paths. JSONL logs append. A refused or failed stage
can leave only the artifacts completed before it stopped.

## Offline verification

Run the existing package tests:

```bash
venv/bin/python -m pytest world_model_rl/tests -q
```

Pytest is a development dependency and is not listed in the runtime requirements.
The tests use generated arrays, small networks, and fake environments; they do not
start CARLA or perform full live training. To check launcher syntax without
executing it:

```bash
bash -n world_model_rl/train_from_scratch.sh
bash -n world_model_rl/recover_from_scratch.sh
```

See [VALIDATION.md](VALIDATION.md) for recorded verification evidence and the
remaining live simulator checks.
